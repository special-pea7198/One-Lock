# 1. Protect the core Flutter engine framework from breaking
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.** { *; }
-keep class io.flutter.util.** { *; }
-keep class io.flutter.view.** { *; }
-keep class io.flutter.** { *; }
-keep class plugins.flutter.io.** { *; }

# 2. Quiet down the Google Play Core split-install warnings we ran into earlier
-dontwarn com.google.android.play.core.**

# 3. Android System Components Keep Rules
# We keep the class names alive so Android OS can launch them, but R8 will 
# still violently scramble all the custom methods and logic inside them!
-keep class com.onelock.applock.MainActivity { *; }
-keep class com.onelock.applock.LockScreenActivity { *; }
-keep class com.onelock.applock.AppLockAccessibilityService { *; }
-keep class com.onelock.applock.BootReceiver { *; }
-keep class com.onelock.applock.OneLockDeviceAdmin { *; }