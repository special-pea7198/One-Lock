package com.onelock.applock

import android.app.AppOpsManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityManager
import android.view.WindowManager
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream

class MainActivity : FlutterFragmentActivity() {
    private val CHANNEL = "com.onelock.applock/apps"
    private var flutterChannel: MethodChannel? = null

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        suppressNotificationBadge()
        startForegroundPollingService()
        WatchdogScheduler.schedule(this)
    }

    private fun startForegroundPollingService() {
        val intent = Intent(this, AppLockForegroundService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun suppressNotificationBadge() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            for (channel in nm.notificationChannels) {
                if (channel.id.contains("lock", ignoreCase = true) ||
                    channel.id.contains("service", ignoreCase = true) ||
                    channel.id.contains("one_lock", ignoreCase = true)) {
                    val updated = NotificationChannel(
                        channel.id, channel.name, NotificationManager.IMPORTANCE_LOW
                    ).apply {
                        setShowBadge(false)
                        setSound(null, null)
                        enableLights(false)
                        enableVibration(false)
                    }
                    nm.createNotificationChannel(updated)
                }
            }
            try {
                val i = Intent("com.sec.android.app.launcher.settingprovider.action.BADGE_COUNT_UPDATE")
                i.putExtra("badge_count", 0)
                i.putExtra("badge_count_package_name", packageName)
                i.putExtra("badge_count_class_name", componentName.className)
                sendBroadcast(i)
            } catch (e: Exception) { /* silent */ }
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        
        flutterChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        
        flutterChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "getInstalledApps"          -> result.success(getInstalledApps())
                "hasUsageStats"             -> result.success(isUsageStatsEnabled())
                "hasAccessibility"          -> result.success(isAccessibilityEnabled())
                "isBatteryOptimized"        -> result.success(isBatteryOptimized())
                "hasOverlayPermission"      -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        result.success(Settings.canDrawOverlays(this@MainActivity))
                    } else {
                        result.success(true)
                    }
                }
                "requestOverlayPermission"  -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        ).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                        }
                        startActivity(intent)
                    }
                    result.success(true)
                }
                "requestUsageStats"         -> {
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                                Intent.FLAG_ACTIVITY_CLEAR_TOP
                    })
                    result.success(true)
                }
                "requestAccessibility"      -> {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                                Intent.FLAG_ACTIVITY_CLEAR_TOP
                    })
                    result.success(true)
                }
                "requestBatteryOptimization" -> {
                    try {
                        val intent = Intent(
                            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:$packageName")
                        )
                        startActivity(intent)
                    } catch (e: Exception) {
                        startActivity(
                            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                        )
                    }
                    result.success(true)
                }
                "requestNotification"       -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        val perm = android.Manifest.permission.POST_NOTIFICATIONS
                        if (checkSelfPermission(perm) !=
                            android.content.pm.PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(arrayOf(perm), 101)
                        }
                    }
                    suppressNotificationBadge()
                    result.success(true)
                }
                "suppressBadge"             -> {
                    suppressNotificationBadge()
                    result.success(true)
                }
                "getLockingEnabled"         -> {
                    val prefs = getSharedPreferences("${packageName}_preferences", Context.MODE_PRIVATE)
                    result.success(prefs.getBoolean("is_locking_enabled", true))
                }
                "setLockingEnabled"         -> {
                    val enabled = call.argument<Boolean>("enabled") ?: true
                    val intent = Intent(this, AppLockForegroundService::class.java)
                    // Same action strings the service's broadcast/onStartCommand
                    // path already handles for pause/resume from its notification.
                    intent.action = if (enabled)
                        "com.onelock.applock.TOGGLE_LOCK"
                    else
                        "com.onelock.applock.CONFIRM_PAUSE"
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        startForegroundService(intent)
                    } else {
                        startService(intent)
                    }
                    result.success(true)
                }
                "refreshLockSettings"       -> {
                    // Called right after Settings writes lock_apps_mode or
                    // unlock_until_screen_off to SharedPreferences -- forces
                    // the service to reload those values immediately instead
                    // of waiting on its lazy cache TTL, and clears any
                    // per-app grace/screen-off state left over from the
                    // previous setting.
                    val intent = Intent(this, AppLockForegroundService::class.java)
                    intent.action = AppLockForegroundService.ACTION_REFRESH_LOCK_SETTINGS
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        startForegroundService(intent)
                    } else {
                        startService(intent)
                    }
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (granted) {
                // The service already called startForeground() in onCreate,
                // possibly before this permission existed -- Android does
                // not retroactively show that notification once permission
                // arrives. Explicitly ask the service to re-post it now.
                val refreshIntent = Intent(this, AppLockForegroundService::class.java)
                refreshIntent.action = AppLockForegroundService.ACTION_REFRESH_NOTIF
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(refreshIntent)
                } else {
                    startService(refreshIntent)
                }
            }
            flutterChannel?.invokeMethod("onNotificationPermissionResult", mapOf(
                "granted" to granted
            ))
        }
    }

    private fun isBatteryOptimized(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return !pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun isUsageStatsEnabled(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(), packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(
            AccessibilityServiceInfo.FEEDBACK_ALL_MASK
        ).any { it.id.contains(packageName) }
    }

    private fun getInstalledApps(): List<Map<String, Any?>> {
        val pm = packageManager
        val intent = android.content.Intent(
            android.content.Intent.ACTION_MAIN, null).apply {
            addCategory(android.content.Intent.CATEGORY_LAUNCHER)
        }
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != this.packageName }
            .map { app ->
                mapOf(
                    "packageName" to app.activityInfo.packageName,
                    "appName"     to app.loadLabel(pm).toString(),
                    "icon"        to try { drawableToBytes(app.loadIcon(pm)) }
                                     catch (e: Exception) { null }
                )
            }
    }

    private fun drawableToBytes(drawable: Drawable): ByteArray {
        val bmp = Bitmap.createBitmap(
            drawable.intrinsicWidth.coerceAtLeast(1),
            drawable.intrinsicHeight.coerceAtLeast(1),
            Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return ByteArrayOutputStream().also {
            bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
        }.toByteArray()
    }
}