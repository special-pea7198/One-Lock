package com.onelock.applock;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/**
 * Schedules the 15-minute AlarmManager watchdog.
 * Called from BootReceiver, MainActivity, and WatchdogReceiver itself
 * to ensure the alarm is always active.
 */
public class WatchdogScheduler {

    private static final long INTERVAL_SCREEN_ON_MS  = 15 * 60 * 1000L; // 15 minutes
    private static final long INTERVAL_SCREEN_OFF_MS = 30 * 60 * 1000L; // 30 minutes
    private static final String ACTION    = "com.onelock.applock.WATCHDOG_ALARM";

    public static void schedule(Context context) {
        AlarmManager am =
                (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        Intent intent = new Intent(ACTION);
        intent.setPackage(context.getPackageName());
        PendingIntent pi = PendingIntent.getBroadcast(
                context, 0, intent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        long intervalMs = AppLockForegroundService.sScreenOn
                ? INTERVAL_SCREEN_ON_MS : INTERVAL_SCREEN_OFF_MS;
        long triggerAt = System.currentTimeMillis() + intervalMs;

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // Android 12+ — use setExactAndAllowWhileIdle if exact alarm
                // permission granted, otherwise fall back to inexact
                if (am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP, triggerAt, pi);
                } else {
                    am.setAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP, triggerAt, pi);
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP, triggerAt, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            }
        } catch (Exception e) {
            // Fallback to inexact if exact scheduling fails
            try {
                am.set(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            } catch (Exception ignored) {}
        }
    }

    public static void cancel(Context context) {
        AlarmManager am =
                (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent intent = new Intent(ACTION);
        intent.setPackage(context.getPackageName());
        PendingIntent pi = PendingIntent.getBroadcast(
                context, 0, intent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        am.cancel(pi);
    }
}
