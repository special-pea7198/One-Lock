package com.onelock.applock;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.core.content.res.ResourcesCompat;

/**
 * Pure visual cover shown via WindowManager the instant a lock decision
 * is made -- before the biometric Activity has had time to fully launch.
 * Paints black, swallows the back button, shows a "Tap fingerprint to
 * unlock" label above a fingerprint icon (offset below vertical center,
 * matching typical S-series lock screen placement). Only the icon itself
 * is tappable -- the rest of the cover just sits there consuming touches
 * (which it already does as a fullscreen window without
 * FLAG_NOT_TOUCH_MODAL) without triggering anything.
 */
public class LockOverlayView extends FrameLayout {

    public interface OnTapListener {
        void onTap();
    }

    /**
     * Lets the owner (the Service) know about things this bare,
     * Activity-less overlay can observe on its own: a back press/gesture,
     * or -- critically -- losing window focus. Home can't be intercepted
     * as a key event (hard OS reservation), but the system reassigns
     * window focus away from this cover almost immediately when Home is
     * pressed/swiped or another window takes over, since this window is
     * focusable. That's a real, near-instant signal, unlike a fixed-delay
     * timer, so it's what actually gets used to dismiss instead of ever
     * making the user (or a reviewer doing rapid app switching) wait.
     */
    public interface OnInteractionListener {
        void onBackPressed();
        void onLostWindowFocus();
    }

    private final ImageView iconView;
    private OnTapListener tapListener;
    private OnInteractionListener interactionListener;

    public LockOverlayView(Context context) {
        super(context);
        setBackgroundColor(Color.BLACK);
        setFocusable(true);
        setFocusableInTouchMode(true);

        float density = context.getResources().getDisplayMetrics().density;

        // 40% smaller than the original 72dp.
        int iconSizePx = Math.round(43 * density);
        int downOffsetPx = Math.round(170 * density); // Increased from 155 to 170 (even lower)

        TextView label = new TextView(context);
        label.setText("Tap fingerprint to unlock");
        label.setTextColor(Color.WHITE);
        label.setTextSize(9f); // Back to 9f
        label.setGravity(Gravity.CENTER);
        try {
            Typeface tf = ResourcesCompat.getFont(context, R.font.lemonmilk);
            label.setTypeface(tf);
        } catch (Exception ignored) {
            // Falls back to the default system typeface if the font
            // resource isn't present -- never let a missing asset crash
            // the lock cover.
        }
        FrameLayout.LayoutParams labelParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        labelParams.gravity = Gravity.CENTER;
        // Sits directly above the icon: icon's top edge is at
        // downOffsetPx - iconSizePx/2 from center, so anchor the label's
        // bottom a little above that.
        labelParams.topMargin = downOffsetPx - (iconSizePx / 2) - Math.round(20 * density); // Decreased gap to 20
        addView(label, labelParams);

        iconView = new ImageView(context);
        iconView.setImageResource(R.drawable.fingerprint_icon);
        iconView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iconView.setClickable(true);
        iconView.setFocusable(true);
        iconView.setOnClickListener(v -> {
            if (tapListener != null) tapListener.onTap();
        });
        // Press effect only: shrink slightly while touched, restore on release.
        // Returns false so the click above still fires exactly as before.
        iconView.setOnTouchListener((v, ev) -> {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(120).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                    break;
            }
            return false;
        });
        FrameLayout.LayoutParams iconParams = new FrameLayout.LayoutParams(iconSizePx, iconSizePx);
        iconParams.gravity = Gravity.CENTER;
        iconParams.topMargin = downOffsetPx;
        addView(iconView, iconParams);
    }

    public void setOnTapListener(OnTapListener listener) {
        this.tapListener = listener;
    }

    public void setOnInteractionListener(OnInteractionListener listener) {
        this.interactionListener = listener;
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            // Previously this just consumed the key and did nothing,
            // which is exactly why back used to appear to "freeze" here:
            // the key never fell through to anything, but nothing ever
            // dismissed this cover either. Now it actually tells the
            // service to close the cover and send the user home.
            if (event.getAction() == KeyEvent.ACTION_UP && interactionListener != null) {
                interactionListener.onBackPressed();
            }
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        super.onWindowFocusChanged(hasWindowFocus);
        if (!hasWindowFocus && interactionListener != null) {
            interactionListener.onLostWindowFocus();
        }
    }

}