package com.onelock.applock;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import androidx.annotation.NonNull;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import java.util.concurrent.Executor;

public class LockScreenActivity extends FragmentActivity {

    private boolean _promptShown = false;
    private String  targetPackage = "";
    private boolean isPauseRequest = false;

    public static boolean isShowing = false;
    private final java.util.concurrent.atomic.AtomicBoolean isDismissing = new java.util.concurrent.atomic.AtomicBoolean(false);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        overridePendingTransition(0, 0); 
        super.onCreate(savedInstanceState);

        if (isShowing) {
            finishAndRemoveTask();
            return;
        }

        // Android's background-activity-start throttling can defer the
        // startActivity() call from launchLockScreen() by many seconds --
        // long after the service already decided (via the abandon logic)
        // that this attempt no longer applies, because the user left
        // before the real activity had a chance to show. If that
        // happened, don't hijack the screen now with a stale lock
        // prompt; just close immediately, silently.
        long attemptId = getIntent() != null ? getIntent().getLongExtra("attempt_id", -1) : -1;
        if (attemptId != -1 && attemptId <= AppLockForegroundService.abandonedAttemptId) {
            finishAndRemoveTask();
            return;
        }

        isShowing = true;
        // Hand off from the instant black cover (if it was shown) to this
        // Activity's own UI -- the overlay's only job was to bridge the
        // gap until this moment.
        AppLockForegroundService.hideOverlayCover();

        getWindow().getDecorView().setBackgroundColor(android.graphics.Color.BLACK);

        getWindow().addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );

        if (getIntent() != null) {
            targetPackage = getIntent().getStringExtra("target_package") != null
                    ? getIntent().getStringExtra("target_package") : "";
            isPauseRequest = getIntent().getBooleanExtra("is_pause_request", false);
        }

        new Handler(Looper.getMainLooper()).postDelayed(this::showBiometricPromptOnce, 50);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null) {
            if (intent.hasExtra("target_package"))
                targetPackage = intent.getStringExtra("target_package");
            isPauseRequest = intent.getBooleanExtra("is_pause_request", false);
        }
        if (!_promptShown) {
            new Handler(Looper.getMainLooper()).postDelayed(this::showBiometricPromptOnce, 50);
        }
    }

    private void showBiometricPromptOnce() {
        if (_promptShown) return;
        _promptShown = true;
        showBiometricPrompt();
    }

    private void showBiometricPrompt() {
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt.AuthenticationCallback callback =
                new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                if (isPauseRequest) {
                    // Was sendBroadcast() to a dynamic receiver -- dropped
                    // silently if the service process had died. Starting
                    // the service directly guarantees delivery.
                    Intent pauseIntent = new Intent(LockScreenActivity.this, AppLockForegroundService.class);
                    pauseIntent.setAction("com.onelock.applock.CONFIRM_PAUSE");
                    ContextCompat.startForegroundService(LockScreenActivity.this, pauseIntent);
                } else {
                    AppLockForegroundService.setTemporaryUnlock(targetPackage);
                }
                
                isShowing = false;
                finishAndRemoveTask();
                overridePendingTransition(0, 0);
            }

            @Override
            public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                goHome();
            }

            @Override
            public void onAuthenticationFailed() {}
        };

        BiometricPrompt prompt = new BiometricPrompt(this, executor, callback);
        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle(isPauseRequest ? "Confirm to Pause" : "Authentication Required")
                .setAllowedAuthenticators(
                        BiometricManager.Authenticators.BIOMETRIC_STRONG |
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                .build();
        prompt.authenticate(info);
    }

    private void goHome() {
        if (!isDismissing.compareAndSet(false, true)) {
            return;
        }

        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_HOME);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            isShowing = false;
            finishAndRemoveTask();
            overridePendingTransition(0, 0);
            isDismissing.set(false);
        }, 300);
    }

    @Override
    protected void onPause() {
        super.onPause();
        overridePendingTransition(0, 0);
    }

    @Override 
    protected void onDestroy() { 
        super.onDestroy(); 
        isShowing = false; 
    }
    
    @Override
    public void onBackPressed() { 
        goHome(); 
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        // Called specifically when the user genuinely navigates away via
        // home/recents gesture -- NOT called for transient system dialogs
        // like the biometric prompt itself. The back-key path already
        // called finishAndRemoveTask() promptly (via goHome()), which
        // reset isShowing in onDestroy(). The home gesture bypasses
        // onBackPressed() entirely, so without this hook Android would
        // just background this Activity (onPause/onStop) without
        // destroying it -- leaving isShowing stuck true indefinitely,
        // blocking every subsequent lock attempt until the OS eventually
        // gets around to destroying the backgrounded Activity on its own
        // unpredictable schedule. Finishing it here closes that gap.
        if (!isDismissing.compareAndSet(false, true)) {
            return;
        }
        isShowing = false;
        finishAndRemoveTask();
        overridePendingTransition(0, 0);
        isDismissing.set(false);
    }
}