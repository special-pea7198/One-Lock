package com.onelock.applock;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.service.notification.StatusBarNotification;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import androidx.annotation.Nullable;
import org.json.JSONArray;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

public class AppLockForegroundService extends Service {

    private static final String CHANNEL_ID          = "one_lock_service_channel";
    // Separate, HIGH-importance channel required for a full-screen intent
    // to actually work -- the main service channel is deliberately LOW so
    // it doesn't ping/pop for the persistent status notification.
    private static final String LOCK_TRIGGER_CHANNEL_ID = "one_lock_trigger_channel";
    private static final int    LOCK_TRIGGER_NOTIF_ID   = 1012;
    private static final int    NOTIF_ID            = 1011;

    // Screen-on default. UsageStats event delivery is the real bottleneck,
    // not this number -- 150ms is already fast enough that tightening it
    // further burns battery with no measurable detection improvement.
    private static final long POLL_RATE_SCREEN_ON_MS  = 150;
    // While the screen is off, nothing the user can "fast switch" into is
    // visible anyway -- slow way down to save battery.
    private static final long POLL_RATE_SCREEN_OFF_MS = 1500;
    private static final long LOCKED_CACHE_TTL_MS      = 3000;
    private static final long NOTIF_CHECK_INTERVAL_MS  = 5000;

    private static final String ACTION_TOGGLE = "com.onelock.applock.TOGGLE_LOCK";
    private static final String ACTION_PAUSE  = "com.onelock.applock.CONFIRM_PAUSE";
    // Fired from MainActivity right after POST_NOTIFICATIONS is granted,
    // so the notification actually appears without requiring a manual
    // Settings toggle.
    public  static final String ACTION_REFRESH_NOTIF = "com.onelock.applock.REFRESH_NOTIF";

    // Fired from MainActivity the instant the person changes "Lock Apps"
    // mode or "Unlock Until Screen Off" in Settings. Two things this
    // fixes: (1) sLockAppsMode/sScreenOffMode were only re-read lazily
    // every LOCKED_CACHE_TTL_MS, so switching modes right before opening
    // an app could still apply the OLD mode for up to ~3s; this forces an
    // immediate reload instead of waiting on that TTL. (2) any per-app
    // grace/screen-off entries recorded under the PREVIOUS setting are
    // stale the moment the setting changes -- e.g. an app authorized
    // under "until screen off" shouldn't silently keep that pass once the
    // person switches to "1 minute" (or back). Both maps are wiped here
    // so every app re-evaluates fresh under whatever is now configured.
    public  static final String ACTION_REFRESH_LOCK_SETTINGS = "com.onelock.applock.REFRESH_LOCK_SETTINGS";

    private static final Object SESSION_LOCK = new Object();
    public  static volatile boolean isLockingEnabled = true;
    private static volatile String  sTempUnlocked    = "";
    private static volatile boolean sInstallerActive = false;
    private static volatile long    sLastUnlockTime  = 0;
    // Whichever app was authenticated right before an installer-family
    // excursion (PackageInstaller/Settings/Play Store) started, even if
    // that app is NOT itself installer-family -- e.g. a file manager
    // handing off to PackageInstaller to install a picked APK. Without
    // this, returning to that app looked like "a brand new app" and
    // forced an immediate re-lock the instant the install flow finished,
    // which is what looked like the app "auto-closing".
    private static volatile String  sInstallerReturnPkg = "";

    // Additive-only tracker for split-screen: remembers every package
    // that's been successfully authenticated, each with the time of its
    // last confirmed authentication. Deliberately separate from
    // sTempUnlocked (a single slot) above -- that slot gets overwritten
    // the moment a *different* package is authenticated, which is exactly
    // right for the normal one-app-at-a-time case, but is the root cause
    // of a split-screen loop: authenticating pane B overwrites pane A's
    // remembered authentication, so the split-screen safeguard sees A as
    // "still on screen, never authenticated" and re-locks it, and vice
    // versa, forever. This map lets multiple concurrently-visible panes
    // stay authenticated at once. Entries are removed the moment that
    // package is actually observed pausing (see checkSplitScreenLockedApps)
    // so it's never a permanent bypass -- closing the pane and reopening
    // that same app fresh still requires re-authentication.
    private static final ConcurrentHashMap<String, Long> sSplitScreenAuthorized = new ConcurrentHashMap<>();
    private static final long SPLIT_AUTH_MAX_AGE_MS = 5 * 60 * 1000L; // safety cap only

    // ── Settings-driven per-app unlock persistence ──────────────────────
    // "Lock Apps" setting: how long a just-unlocked app stays unlocked
    // after you leave it. "immediate" (default) means no grace at all --
    // the existing sTempUnlocked/isAppLocked path already covers that.
    // "1min" adds a per-package expiry so leaving app A unlocked for a
    // minute never affects app B (each package gets its own entry here).
    private static final ConcurrentHashMap<String, Long> sPerAppGraceExpiry = new ConcurrentHashMap<>();
    private static final long ONE_MINUTE_GRACE_MS = 60 * 1000L;

    // "Unlock Until Screen Off" setting: once unlocked, a package stays
    // unlocked (independently of any other package) until the screen
    // actually turns off, at which point this whole set is cleared and
    // every app's lock resets. Mutually exclusive with the 1-minute grace
    // above -- only one of the two is ever populated, enforced both in
    // Settings (UI greys the other out) and in setTemporaryUnlock below.
    private static final Set<String> sPerAppUnlockedUntilScreenOff = new CopyOnWriteArraySet<>();

    // Cached copies of the two Flutter-side settings, refreshed alongside
    // the locked-apps cache in refreshLockedAppsCache() so we don't hit
    // SharedPreferences on every single foreground-change event.
    private static volatile String  sLockAppsMode   = "immediate"; // "immediate" | "1min"
    private static volatile boolean sScreenOffMode  = false;

    // Read by WatchdogScheduler to pick the 15-min (screen on) vs
    // 30-min (screen off) restart-check interval.
    public static volatile boolean sScreenOn = true;

    // Lets LockScreenActivity reach the live service instance (to hide
    // the overlay cover) without a hard static reference / leak risk.
    private static volatile WeakReference<AppLockForegroundService> sInstance;

    private HandlerThread pollingThread;
    private Handler       pollingHandler;
    private Handler       mainHandler;
    private volatile long currentPollRateMs = POLL_RATE_SCREEN_ON_MS;

    private final AtomicBoolean           isPolling       = new AtomicBoolean(false);
    private final AtomicReference<String> lastForeground  = new AtomicReference<>("");
    private final AtomicReference<String> lastLockedPkg   = new AtomicReference<>("");

    private final CopyOnWriteArraySet<String> lockedSet = new CopyOnWriteArraySet<>();
    private volatile long    lastLockedCacheTime  = 0;
    private final AtomicBoolean cacheRefreshing   = new AtomicBoolean(false);
    private volatile long    lastNotifCheckTime   = 0;

    // Set the instant we DECIDE to lock, not when LockScreenActivity's own
    // onCreate happens to run. Extra safety against a stray poll calling
    // launchLockScreen() twice for the same transition.
    private final AtomicBoolean lockTriggerInFlight = new AtomicBoolean(false);

    // Tags every launchLockScreen() call so a LockScreenActivity that
    // Android chooses to actually start much later (background-activity-
    // start throttling can defer startActivity() by many seconds) can
    // tell whether the world has already moved on since it was requested.
    // When an attempt is abandoned (see the three "abandoning stuck
    // overlay" call sites), abandonedAttemptId is bumped to match it; if
    // LockScreenActivity.onCreate() ever runs for an attempt at or below
    // that id, it means this launch is stale and should just close
    // itself instead of popping up over whatever the user is doing now.
    private static final AtomicLong lockAttemptCounter = new AtomicLong(0);
    private volatile long currentAttemptId = 0;
    public static volatile long abandonedAttemptId = -1;

    // ── Instant black cover, shown via WindowManager the moment a lock
    // decision is made. Purely visual -- carries no auth logic. Removed
    // the instant LockScreenActivity's real UI is up, or after a short
    // safety timeout if that Activity never manages to start at all.
    private WindowManager   windowManager;
    private LockOverlayView overlayView;
    private boolean         overlayAttached = false;
    // Whether the cover's window is currently inserted into the
    // WindowManager. Separate from overlayAttached (which just means the
    // View instance + listeners exist). The cover is fully removed and
    // freshly re-added on every show, rather than toggled GONE/VISIBLE on
    // a window that stays inserted forever -- a persistently-inserted
    // overlay window can occasionally end up composited BEHIND whatever
    // app window is animating in during a fast task switch (a real
    // WindowManager z-order race during transition animations), which is
    // what let the app underneath show through and made the cover
    // unresponsive to touch/back at the same time. A fresh addView() each
    // time forces it back to the top of its layer every single show.
    private boolean         overlayWindowAdded = false;

    // A permanent, invisible-to-the-eye 1x1px overlay window, attached
    // once at service start and never removed. Its only purpose is to
    // keep this app continuously satisfying Android's "app is currently
    // showing an overlay" exemption for starting an Activity from the
    // background -- so launchLockScreen()'s startActivity() call no
    // longer races against the visible black cover's addView() finishing
    // in time. It does nothing, has no listeners, and is never shown or
    // hidden after initial attach.
    private View anchorPixelView;
    private boolean anchorAttached = false;

    private static final Set<String> LAUNCHERS = new HashSet<>(Arrays.asList(
        "com.sec.android.app.launcher", "com.samsung.android.app.launcher",
        "com.samsung.android.launcher", "com.android.launcher",
        "com.android.launcher2", "com.android.launcher3",
        "com.android.systemlauncher", "com.google.android.apps.nexuslauncher",
        "com.miui.home", "com.huawei.android.launcher",
        "com.oppo.launcher", "com.vivo.launcher"
    ));

    private static final Set<String> SYSTEM_PKGS = new HashSet<>(Arrays.asList(
        "android", "com.android.systemui", "com.samsung.android.systemui",
        "com.android.inputmethod.latin", "com.google.android.inputmethod.latin",
        "com.samsung.android.honeyboard", "com.samsung.android.inputmethod",
        "com.sec.android.inputmethod", "com.google.android.googlequicksearchbox",
        "com.android.permissioncontroller", "com.samsung.android.permissioncontroller",
        "com.android.providers.media", "com.android.documentsui",
        "com.samsung.android.app.clipboardedge", "com.samsung.android.app.cocktailbarservice",
        "com.google.android.as", "com.google.android.gms",
        "com.samsung.android.bixby.agent", "com.samsung.android.bixby.service",
        "com.samsung.android.bixbyvision.framework", "com.google.android.apps.assistant",
        "com.samsung.android.app.assistantmenu", "com.samsung.android.sm.policy",
        "com.sec.android.app.samsungapps", "com.samsung.android.drivelink.stub",
        "com.samsung.android.knox.containeragent"
    ));

    private static final Set<String> INSTALLER_FAMILY = new HashSet<>(Arrays.asList(
        "com.android.packageinstaller", "com.google.android.packageinstaller",
        "com.miui.packageinstaller", "com.samsung.android.packageinstaller",
        "com.sec.android.app.packageinstaller", "com.huawei.android.packageinstaller",
        "com.android.settings", "com.samsung.android.settings",
        "com.sec.android.app.settings", "com.android.vending",
        "com.samsung.android.vending", "com.sec.android.app.samsungapps"
    ));

    // Narrower than INSTALLER_FAMILY above. INSTALLER_FAMILY also includes
    // Settings and Play Store -- needed so an install flow can hand off
    // through them without losing its authenticated session (see the
    // installer-excursion logic in processPackage). But "Uninstall
    // Protection" in the app (see AppLockService._installerPackages on the
    // Dart side) only ever locks the actual PackageInstaller packages --
    // never Settings itself. Using the broad set for the "no grace ever"
    // rule was wrongly catching a genuinely-locked Settings app and
    // forcing it to re-auth every time even outside any install flow.
    // This narrow set is what the per-app grace/screen-off exclusion
    // should actually check.
    private static final Set<String> UNINSTALL_PROTECTION_PKGS = new HashSet<>(Arrays.asList(
        "com.android.packageinstaller", "com.google.android.packageinstaller",
        "com.miui.packageinstaller", "com.samsung.android.packageinstaller",
        "com.sec.android.app.packageinstaller", "com.huawei.android.packageinstaller"
    ));

    private static final Set<String> YOUTUBE_FAMILY = new HashSet<>(Arrays.asList(
        "com.google.android.youtube", "com.google.android.apps.youtube.creator",
        "com.google.android.apps.youtube.music", "com.google.android.youtube.tv",
        "com.google.android.apps.youtube.unplugged"
    ));

    public static void setTemporaryUnlock(String packageName) {
        synchronized (SESSION_LOCK) {
            sTempUnlocked   = packageName;
            sLastUnlockTime = System.currentTimeMillis();
            if (isInstallerFamilyPkg(packageName)) {
                sInstallerActive = true;
            }
        }
        if (packageName != null && !packageName.isEmpty()) {
            sSplitScreenAuthorized.put(packageName, System.currentTimeMillis());

            // Uninstall protection is a hard exception: it must always
            // re-challenge with zero grace no matter what these two
            // settings are, so it never gets an entry here. Note this is
            // the NARROW uninstall-protection set, not the broader
            // installer-family set -- a genuinely locked Settings app
            // should still get its normal grace/screen-off behavior.
            if (!isUninstallProtectionPkg(packageName)) {
                if ("1min".equals(sLockAppsMode)) {
                    sPerAppGraceExpiry.put(packageName, System.currentTimeMillis() + ONE_MINUTE_GRACE_MS);
                } else if (sScreenOffMode) {
                    sPerAppUnlockedUntilScreenOff.add(packageName);
                }
            }
        }
    }

    private static void clearSession() {
        synchronized (SESSION_LOCK) {
            sTempUnlocked       = "";
            sInstallerActive    = false;
            sInstallerReturnPkg = "";
        }
    }

    private void loadLockState() {
        SharedPreferences prefs = getSharedPreferences(getPackageName() + "_preferences", MODE_PRIVATE);
        isLockingEnabled = prefs.getBoolean("is_locking_enabled", true);
    }

    private void saveLockState(boolean state) {
        SharedPreferences prefs = getSharedPreferences(getPackageName() + "_preferences", MODE_PRIVATE);
        prefs.edit().putBoolean("is_locking_enabled", state).apply();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        loadLockState();
        sInstance = new WeakReference<>(this);
        mainHandler = new Handler(Looper.getMainLooper());
        // Elevated from THREAD_PRIORITY_BACKGROUND so the detection loop
        // competes better for CPU time against Flutter/UI work.
        pollingThread = new HandlerThread("OneLockPoller", android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY);
        pollingThread.start();
        pollingHandler = new Handler(pollingThread.getLooper());

        createNotificationChannel();
        startForeground(NOTIF_ID, buildNotification());
        registerToggleReceiver();
        registerScreenStateReceiver();
        registerHomePressReceiver();
        refreshLockedAppsCache();
        attachAnchorPixel();
    }

    // Attached once, kept for the entire lifetime of the service. See
    // the field comment on anchorPixelView for why this exists.
    private void attachAnchorPixel() {
        if (anchorAttached) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            return; // no permission -- lock screen still works via the
                     // direct startActivity()/full-screen-intent paths,
                     // just without this extra reliability layer.
        }
        try {
            WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            View pixel = new View(this);

            int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;

            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    1, 1,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    android.graphics.PixelFormat.TRANSLUCENT);
            params.gravity = android.view.Gravity.TOP | android.view.Gravity.START;
            params.x = 0;
            params.y = 0;

            wm.addView(pixel, params);
            anchorPixelView = pixel;
            windowManager = wm; // reuse the same WindowManager instance for the visible cover too
            anchorAttached = true;
        } catch (Exception e) {
            anchorAttached = false;
            anchorPixelView = null;
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Handled here, not only via the dynamic BroadcastReceiver below,
        // because starting a service via PendingIntent reliably revives a
        // killed process; a plain broadcast to an already-dead dynamic
        // receiver is silently dropped. This is what makes Resume work
        // even if the process died between Pause and Resume.
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_TOGGLE.equals(action)) {
                isLockingEnabled = true;
                saveLockState(true);
                updateNotification();
            } else if (ACTION_PAUSE.equals(action)) {
                isLockingEnabled = false;
                saveLockState(false);
                clearSession();
                lastLockedPkg.set("");
                sSplitScreenAuthorized.clear();
                sPerAppGraceExpiry.clear();
                sPerAppUnlockedUntilScreenOff.clear();
                updateNotification();
            } else if (ACTION_REFRESH_NOTIF.equals(action)) {
                updateNotification();
            } else if (ACTION_REFRESH_LOCK_SETTINGS.equals(action)) {
                forceRefreshLockSettingsAndClearState();
            }
        }
        if (!isPolling.get()) {
            isPolling.set(true);
            schedulePoll();
        }
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        Intent restartIntent = new Intent(getApplicationContext(), AppLockForegroundService.class);
        restartIntent.setPackage(getPackageName());
        PendingIntent pi = PendingIntent.getService(
                getApplicationContext(), 1, restartIntent,
                PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarm = (AlarmManager) getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        if (alarm != null) {
            alarm.set(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 1000, pi);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isPolling.set(false);
        sInstance = null;
        try { unregisterReceiver(toggleReceiver); } catch (Exception ignored) {}
        try { unregisterReceiver(screenStateReceiver); } catch (Exception ignored) {}
        try { unregisterReceiver(homePressReceiver); } catch (Exception ignored) {}
        stopOverlayWatchdog();
        try {
            if (overlayWindowAdded && windowManager != null && overlayView != null) {
                windowManager.removeView(overlayView);
            }
        } catch (Exception ignored) {}
        try {
            if (anchorAttached && windowManager != null && anchorPixelView != null) {
                windowManager.removeView(anchorPixelView);
            }
        } catch (Exception ignored) {}
        if (pollingThread != null) pollingThread.quitSafely();
    }

    @Nullable @Override
    public IBinder onBind(Intent intent) { return null; }

    private final BroadcastReceiver toggleReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (ACTION_TOGGLE.equals(action)) {
                isLockingEnabled = true;
                saveLockState(true);
                updateNotification();
            } else if (ACTION_PAUSE.equals(action)) {
                isLockingEnabled = false;
                saveLockState(false);
                clearSession();
                lastLockedPkg.set("");
                sSplitScreenAuthorized.clear();
                sPerAppGraceExpiry.clear();
                sPerAppUnlockedUntilScreenOff.clear();
                updateNotification();
            }
        }
    };

    private void registerToggleReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_TOGGLE);
        filter.addAction(ACTION_PAUSE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(toggleReceiver, filter, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(toggleReceiver, filter);
        }
    }

    // ── Screen on/off: throttle polling and watchdog cadence to save
    // battery while nothing is on-screen to fast-switch into. ──
    private final BroadcastReceiver screenStateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (Intent.ACTION_SCREEN_OFF.equals(action)) {
                sScreenOn = false;
                currentPollRateMs = POLL_RATE_SCREEN_OFF_MS;
                // Screen turning off is exactly the reset signal for
                // "Unlock Until Screen Off" -- every app's grant is
                // cleared here, per-app, all at once.
                sPerAppUnlockedUntilScreenOff.clear();
                WatchdogScheduler.schedule(getApplicationContext());
            } else if (Intent.ACTION_SCREEN_ON.equals(action)) {
                sScreenOn = true;
                currentPollRateMs = POLL_RATE_SCREEN_ON_MS;
                WatchdogScheduler.schedule(getApplicationContext());
            }
        }
    };

    private void registerScreenStateReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // System-protected actions -- only the OS can ever send these,
            // so NOT_EXPORTED is the correct, least-privilege choice.
            registerReceiver(screenStateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(screenStateReceiver, filter);
        }
    }

    public void updateNotification() {
        mainHandler.post(() -> {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_ID, buildNotification());
        });
    }

    private Notification buildNotification() {
        Intent mainIntent = new Intent(this, MainActivity.class);
        mainIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent mainPi = PendingIntent.getActivity(this, 0, mainIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        PendingIntent actionPi;
        String actionLabel;
        if (isLockingEnabled) {
            Intent authIntent = new Intent(this, LockScreenActivity.class);
            authIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            authIntent.putExtra("is_pause_request", true);
            actionPi = PendingIntent.getActivity(this, 2, authIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            actionLabel = "Pause";
        } else {
            // Uses getForegroundService (not getBroadcast) so Resume works
            // reliably even if the process died since Pause was tapped --
            // starting a service revives a dead process, a broadcast to an
            // already-dead dynamic receiver does not.
            Intent toggleIntent = new Intent(this, AppLockForegroundService.class);
            toggleIntent.setAction(ACTION_TOGGLE);
            actionPi = PendingIntent.getForegroundService(this, 1, toggleIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            actionLabel = "Resume";
        }

        String statusText = isLockingEnabled ? "Service Active" : "Service Paused";

        // If the user swipes the notification away (Android 14+ allows this
        // even for foreground services), this fires and the service reposts it.
        Intent refreshIntent = new Intent(this, AppLockForegroundService.class);
        refreshIntent.setAction(ACTION_REFRESH_NOTIF);
        PendingIntent deletePi = PendingIntent.getService(this, 3, refreshIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification notification;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notification = new Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle(statusText)
                    .setSmallIcon(R.drawable.vaulticon_small)
                    .setContentIntent(mainPi)
                    .addAction(new Notification.Action.Builder(null, actionLabel, actionPi).build())
                    .setOngoing(true)
                    .setDeleteIntent(deletePi)
                    .setShowWhen(false)
                    .build();
        } else {
            notification = new Notification.Builder(this)
                    .setContentTitle(statusText)
                    .setSmallIcon(R.drawable.vaulticon_small)
                    .setContentIntent(mainPi)
                    .setOngoing(true)
                    .setDeleteIntent(deletePi)
                    .setShowWhen(false)
                    .build();
        }
        notification.flags |= Notification.FLAG_ONGOING_EVENT | Notification.FLAG_NO_CLEAR;
        return notification;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "One Lock Service", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false); ch.setSound(null, null); ch.enableLights(false); ch.enableVibration(false);
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                nm.createNotificationChannel(ch);

                // HIGH importance is required for a full-screen intent to
                // actually trigger -- this channel exists purely so the
                // OS-sanctioned "launch an Activity from background"
                // mechanism (used by call/alarm apps) works reliably,
                // sidestepping the background-activity-start restriction
                // that appears to be silently blocking direct
                // startActivity() calls from this service on some devices.
                NotificationChannel trigger = new NotificationChannel(
                        LOCK_TRIGGER_CHANNEL_ID, "App Lock Trigger", NotificationManager.IMPORTANCE_HIGH);
                trigger.setShowBadge(false);
                trigger.setSound(null, null);
                trigger.enableVibration(false);
                trigger.setBypassDnd(true);
                nm.createNotificationChannel(trigger);
            }
        }
    }

    private void schedulePoll() {
        if (!isPolling.get()) return;
        pollingHandler.postDelayed(this::poll, currentPollRateMs);
    }

    private void poll() {
        if (!isPolling.get()) return;
        try {
            if (!isLockingEnabled) {
                // Keep the notification alive while paused too, so Resume stays reachable
                checkNotificationPersistence();
                schedulePoll();
                return;
            }
            String fg = getForegroundPackage();
            if (!fg.isEmpty()) {
                handleForegroundCandidate(fg);
            }
            checkSplitScreenLockedApps();
            checkNotificationPersistence();
            schedulePoll();
        } catch (Exception e) {
            schedulePoll();
        }
    }

    // Shared by the poll loop's fg-change detection so both the "normal"
    // and split-screen paths funnel through identical logic and state.
    // Records the last locked package we transitioned AWAY from, and when.
    // Used by checkSplitScreenLockedApps to avoid mistaking "I just left
    // this app" (its RESUMED event still sitting in the scan window,
    // PAUSED not yet registered) for "this app is genuinely visible in a
    // second split-screen pane" -- the false positive that was causing an
    // immediate relock the instant the user pressed home after unlocking.
    private volatile String justDepartedLockedPkg = "";
    private volatile long   justDepartedTime      = 0;
    private static final long DEPARTURE_SHIELD_MS = 1500;

    private void handleForegroundCandidate(String fg) {
        if (fg == null || fg.isEmpty()) return;
        String prev = lastForeground.get();
        if (!fg.equals(prev)) {
            Log.d("OneLockDebug", "fg changed " + prev + " -> " + fg);
            if (!prev.isEmpty() && !prev.equals(fg) && isAppLocked(prev)) {
                justDepartedLockedPkg = prev;
                justDepartedTime = System.currentTimeMillis();
            }
            lastForeground.set(fg);
            processPackage(fg, prev);
        }
    }

    private void processPackage(String pkg, String prevPkg) {
        if (pkg.equals(getPackageName())) return;
        if (isSystemPkg(pkg)) return;

        // The black cover is shown the instant a lock decision is made,
        // ahead of LockScreenActivity actually reaching the foreground.
        // If the user hits back/home (or switches to yet another app)
        // during that gap, LockScreenActivity may never come up at all --
        // and since the cover is a plain WindowManager view (not an
        // Activity), it never gets an onPause/onUserLeaveHint to tell it
        // the user left. Left alone it just sits there, stuck and
        // unresponsive, forever "waiting" for a screen that isn't coming.
        // Detect that here: if a lock is in flight (or the cover is up)
        // but LockScreenActivity never actually became visible, and the
        // foreground has now genuinely moved to something other than the
        // package we were trying to lock, abandon the attempt.
        if (!LockScreenActivity.isShowing && isOverlayCoverShowing()) {
            // NOTE: deliberately does NOT gate on lockTriggerInFlight --
            // that flag self-clears 1.5s after launchLockScreen() fires
            // (see the postDelayed in that method), regardless of
            // whether the cover is still up. Gating on it meant this
            // check silently did nothing once more than ~1.5s had
            // passed since the lock attempt started, which is exactly
            // the common case for a slower back/home press -- the cover
            // stayed stuck. The cover's own visibility is the real
            // signal we care about here.
            String pending = lastLockedPkg.get();
            if (pending == null || !pending.equals(pkg)) {
                Log.d("OneLockDebug", "processPackage: abandoning stuck overlay, fg moved to " + pkg + " while pending was " + pending);
                lockTriggerInFlight.set(false);
                abandonedAttemptId = currentAttemptId;
                hideOverlayCoverInternal();
            }
        }

        String  tempUnlocked;
        boolean installerActive;
        String  installerReturnPkg;
        synchronized (SESSION_LOCK) {
            tempUnlocked       = sTempUnlocked;
            installerActive    = sInstallerActive;
            installerReturnPkg = sInstallerReturnPkg;
        }

        if (isLauncherPkg(pkg)) {
            if (getPackageName().equals(prevPkg)) {
                // The foreground immediately before this was OUR OWN lock
                // screen, not the target app -- this launcher appearance
                // is the unlock-transition animation still settling
                // (LockScreenActivity finishing before the target app's
                // task has fully resumed), not a genuine Home press.
                // Ignore it. Deliberately not time-based: a fixed
                // millisecond window here raced against how fast the user
                // happened to act, which is exactly why this used to work
                // sometimes and not others for the exact same action.
                return;
            }
            clearSession();
            lastLockedPkg.set("");
            return;
        }

        boolean pkgIsInstallerFamily = isInstallerFamilyPkg(pkg);

        // Entering (or continuing within) the installer/settings/Play
        // Store flow. Only treat this as a free passthrough when there's
        // an actual authenticated session to preserve across it -- either
        // already mid-excursion, or some app was genuinely authenticated
        // right before this (even if that app isn't itself
        // installer-family, e.g. a file manager handing a picked APK to
        // PackageInstaller). If NEITHER is true -- nothing authenticated
        // at all -- this must fall through to the normal isAppLocked()
        // check below. That's what lets "uninstall protection" actually
        // challenge Settings/PackageInstaller themselves (e.g. someone
        // tries to uninstall this app with no prior unlock in play);
        // unconditionally bypassing here was the regression that silently
        // broke that check entirely.
        if (pkgIsInstallerFamily && (installerActive || !tempUnlocked.isEmpty())) {
            synchronized (SESSION_LOCK) {
                if (!installerActive) {
                    sInstallerReturnPkg = tempUnlocked;
                }
                sInstallerActive = true;
            }
            lastLockedPkg.set(pkg);
            return;
        }

        // Coming back from that excursion to the exact app we left --
        // restore its session instead of treating it as a brand new app
        // that needs a fresh unlock. This is what used to force an
        // unwanted re-lock (looking like the app had "closed") whenever
        // the app that triggered the installer flow wasn't itself
        // installer-family.
        if (installerActive && !installerReturnPkg.isEmpty() && pkg.equalsIgnoreCase(installerReturnPkg)) {
            synchronized (SESSION_LOCK) {
                sInstallerActive    = false;
                sTempUnlocked       = installerReturnPkg;
                sInstallerReturnPkg = "";
            }
            lastLockedPkg.set(pkg);
            return;
        }
        if (installerActive) {
            // Excursion ended somewhere else entirely (user backed out
            // to a different app rather than returning to the original
            // one) -- the excursion is over either way, don't leave it
            // dangling for next time.
            synchronized (SESSION_LOCK) {
                sInstallerActive    = false;
                sInstallerReturnPkg = "";
            }
        }

        boolean sameAsUnlocked = !tempUnlocked.isEmpty() &&
                (pkg.equalsIgnoreCase(tempUnlocked) ||
                 (pkgIsInstallerFamily && isInstallerFamilyPkg(tempUnlocked)) ||
                 (YOUTUBE_FAMILY.contains(pkg) && YOUTUBE_FAMILY.contains(tempUnlocked)));

        if (sameAsUnlocked) {
            lastLockedPkg.set(pkg);
            return;
        }

        // ── Lock Apps grace / Unlock Until Screen Off ───────────────────
        // Deliberately excluded for uninstall-protection packages only
        // (the narrow PackageInstaller set) -- NOT the broader
        // pkgIsInstallerFamily flag, which also covers Settings/Play
        // Store for excursion pass-through. A genuinely locked Settings
        // app must still get its normal grace/screen-off behavior; only
        // real uninstall protection re-challenges with zero grace.
        if (!isUninstallProtectionPkg(pkg)) {
            Long graceExpiry = sPerAppGraceExpiry.get(pkg);
            if (graceExpiry != null) {
                if (System.currentTimeMillis() < graceExpiry) {
                    lastLockedPkg.set(pkg);
                    return;
                } else {
                    sPerAppGraceExpiry.remove(pkg);
                }
            }
            if (sPerAppUnlockedUntilScreenOff.contains(pkg)) {
                lastLockedPkg.set(pkg);
                return;
            }
        }

        // Structural filter, not a name-based blocklist: a package the
        // user could never even open by tapping an icon (no launcher
        // entry point at all) can't be something they deliberately
        // opened, so it can't be the reason to re-evaluate a lock. Never
        // touches isAppLocked itself, so it can't create a "free pass" --
        // anything the user actually picked to lock is, by definition,
        // something they can launch. Installer-family packages are
        // exempt from this specific filter -- PackageInstaller itself
        // typically has NO launcher icon at all, so without this
        // exemption uninstall protection could never challenge it either.
        if (!pkgIsInstallerFamily && !isAppLaunchable(pkg)) return;

        clearSession();

        if (isAppLocked(pkg)) {
            Log.d("OneLockDebug", "processPackage: " + pkg + " is locked, isShowing=" + LockScreenActivity.isShowing + " inFlight=" + lockTriggerInFlight.get());
            if (LockScreenActivity.isShowing || lockTriggerInFlight.get()) {
                // Do NOT reset lastForeground here. Clearing it made the
                // next poll see "" -> pkg as a fresh change, re-entering
                // this same branch every single cycle while the lock
                // screen was already up -- spawning repeated duplicate
                // LockScreenActivity/BiometricPrompt attempts that
                // cancelled each other (the repeated onError:10 entries
                // in the log).
                return;
            }

            lastLockedPkg.set(pkg);
            launchLockScreen(pkg);
        } else {
            lastLockedPkg.set(pkg);
        }
    }

    private String getForegroundPackage() {
        long now = System.currentTimeMillis();
        try {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
            if (usm == null) return lastForeground.get();

            // Widened from 2000ms so events delayed by OEM battery-
            // optimization batching are less likely to be missed entirely.
            UsageEvents events = usm.queryEvents(now - 5000, now + 1000);
            UsageEvents.Event event = new UsageEvents.Event();

            long latestTime = 0;
            String latestPkg = lastForeground.get();

            while (events.hasNextEvent()) {
                events.getNextEvent(event);
                if (event.getEventType() == UsageEvents.Event.ACTIVITY_RESUMED) {
                    if (event.getTimeStamp() > latestTime) {
                        latestPkg = event.getPackageName();
                        latestTime = event.getTimeStamp();
                    }
                }
            }
            return latestPkg;
        } catch (Exception e) {
            return lastForeground.get();
        }
    }

    // ── Split-screen safeguard ──────────────────────────────────────────
    // In split-screen, tapping the unlocked pane can make the primary
    // fg-tracking path above think "the locked app is no longer active"
    // even though it's still sitting visibly in the other pane. This is a
    // strictly additive check: it never touches lastForeground or session
    // state, it only looks for a locked package whose most recent event
    // in the window is RESUMED (not superseded by a later PAUSED) and
    // locks if one is found and nothing is already showing/in-flight.
    private void checkSplitScreenLockedApps() {
        if (!isLockingEnabled) return;
        try {
            long now = System.currentTimeMillis();
            UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
            if (usm == null) return;

            UsageEvents events = usm.queryEvents(now - 3000, now + 1000);
            UsageEvents.Event event = new UsageEvents.Event();
            Map<String, Integer> lastEventTypeForPkg = new HashMap<>();

            while (events.hasNextEvent()) {
                events.getNextEvent(event);
                int type = event.getEventType();
                if (type == UsageEvents.Event.ACTIVITY_RESUMED || type == UsageEvents.Event.ACTIVITY_PAUSED) {
                    lastEventTypeForPkg.put(event.getPackageName(), type);
                }
            }

            for (Map.Entry<String, Integer> e : lastEventTypeForPkg.entrySet()) {
                if (e.getValue() == UsageEvents.Event.ACTIVITY_PAUSED) {
                    // This pane actually left -- its earlier split-screen
                    // authorization (if any) no longer applies. Without
                    // this, a package could stay "pre-authorized" forever
                    // after its very first unlock, which would be a real
                    // bypass, not just a split-screen convenience.
                    sSplitScreenAuthorized.remove(e.getKey());
                }
            }
            // Safety cap only, in case a PAUSED event is ever missed
            // entirely (e.g. the pane was killed outright rather than
            // cleanly backgrounded) -- bounds how long an authorization
            // can theoretically linger.
            sSplitScreenAuthorized.entrySet().removeIf(en -> (now - en.getValue()) > SPLIT_AUTH_MAX_AGE_MS);

            for (Map.Entry<String, Integer> e : lastEventTypeForPkg.entrySet()) {
                String pkg = e.getKey();
                if (e.getValue() != UsageEvents.Event.ACTIVITY_RESUMED) continue;
                if (pkg.equals(getPackageName())) continue;
                if (pkg.equals(lastForeground.get())) continue; // already handled by the main path

                // Was this the app the user just navigated away from? If
                // so, its RESUMED event is stale (the PAUSED event just
                // hasn't registered yet) -- not a genuine second
                // split-screen pane. Skip it during the shield window.
                if (pkg.equals(justDepartedLockedPkg) && (now - justDepartedTime) < DEPARTURE_SHIELD_MS) {
                    continue;
                }

                // Already authenticated earlier in this session (in this
                // pane or a previous one) and hasn't actually paused since
                // -- see the pruning above. This is what stops the
                // authenticate-A / authenticate-B / re-lock-A /
                // re-lock-B loop: both panes can stay authorized at the
                // same time instead of a single slot fighting itself.
                if (sSplitScreenAuthorized.containsKey(pkg)) continue;

                // Same bypass processPackage() applies on the main path --
                // without this, a package legitimately still unlocked
                // (1-min grace or "until screen off") could get relocked
                // here the moment its sSplitScreenAuthorized entry aged
                // out, even though the user never left it.
                if (hasPerAppUnlockBypass(pkg)) continue;

                if (isAppLocked(pkg) && !LockScreenActivity.isShowing && !lockTriggerInFlight.get()) {
                    Log.d("OneLockDebug", "split-screen: locked app active in secondary pane: " + pkg);
                    lastLockedPkg.set(pkg);
                    launchLockScreen(pkg);
                    break; // one lock screen at a time
                }
            }
        } catch (Exception ignored) {}
    }

    // ── Persistent notification ─────────────────────────────────────────
    // Safety net beyond setOngoing(true)/onTaskRemoved: periodically
    // verify the notification is actually still posted, and re-post it
    // if some OEM notification-management path managed to dismiss it.
    private void checkNotificationPersistence() {
        long now = System.currentTimeMillis();
        if (now - lastNotifCheckTime < NOTIF_CHECK_INTERVAL_MS) return;
        lastNotifCheckTime = now;
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return; // getActiveNotifications() needs 23+
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            boolean found = false;
            for (StatusBarNotification sbn : nm.getActiveNotifications()) {
                if (sbn.getId() == NOTIF_ID) { found = true; break; }
            }
            if (!found) {
                updateNotification();
            }
        } catch (Exception ignored) {}
    }

    // ── Overlay cover ────────────────────────────────────────────────────
    private void ensureOverlayCreated() {
        if (overlayAttached) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            // No permission -- silently skip. LockScreenActivity still
            // launches and works on its own, just without the instant
            // cover; this is an enhancement, never a hard dependency.
            return;
        }
        try {
            windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            overlayView = new LockOverlayView(this);
            overlayView.setOnTapListener(this::onOverlayTapped);
            overlayView.setOnInteractionListener(new LockOverlayView.OnInteractionListener() {
                @Override
                public void onBackPressed() {
                    dismissOverlayAndGoHome();
                }

                @Override
                public void onLostWindowFocus() {
                    // If LockScreenActivity is legitimately taking over
                    // right now (the normal, working hand-off path -- a
                    // tap on the icon, or the activity managing to start
                    // on its own), losing focus here is expected and
                    // that Activity's own onCreate already calls
                    // hideOverlayCover(). Only even consider losing
                    // focus as "the user left" when that hand-off is NOT
                    // in progress.
                    if (LockScreenActivity.isShowing) return;

                    // Window focus can also change for reasons that have
                    // nothing to do with the user leaving -- e.g. the
                    // locked app itself starting video playback, going
                    // fullscreen, or dropping into a mini-player can all
                    // steal window focus momentarily. Blindly trusting
                    // this signal let those cases dismiss the cover and
                    // send the user straight through to the unprotected
                    // app underneath -- a real bypass, not just a visual
                    // glitch. Verify against the same decisive "has the
                    // locked app actually paused" check the watchdog
                    // uses before acting on it.
                    String pending = lastLockedPkg.get();
                    if (hasPendingLeftForeground(pending)) {
                        dismissOverlayAndGoHome();
                    }
                    // If not yet confirmed, do nothing here -- the
                    // watchdog (already polling every 100ms with the same
                    // decisive check) will catch a genuine departure
                    // shortly after anyway. Better to be a little slower
                    // on Home than to risk an unverified bypass.
                }
            });
            overlayAttached = true;
        } catch (Exception e) {
            overlayAttached = false;
            overlayView = null;
        }
    }

    private WindowManager.LayoutParams buildOverlayLayoutParams() {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                // Deliberately NOT setting FLAG_NOT_TOUCH_MODAL: this
                // window covers the full screen, so omitting it means
                // all touches are consumed here rather than passed to
                // whatever is underneath -- exactly what a lock cover
                // needs to do.
                WindowManager.LayoutParams.FLAG_FULLSCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                android.graphics.PixelFormat.OPAQUE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // Without this, the cover leaves the notch/cutout area
            // and gesture-nav inset strip uncovered on many devices,
            // which is the "not actually full screen" gap.
            params.layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
                    ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        return params;
    }

    // Shared by: the back key handler, the window-focus-loss handler, and
    // can be reused anywhere else a "give up and reset" is needed. Hides
    // the cover, clears every bit of in-flight lock state so the next
    // open of a locked app starts clean, and pushes the user to the real
    // Home screen so nothing stale is left showing.
    private void dismissOverlayAndGoHome() {
        hideOverlayCoverInternal();
        lockTriggerInFlight.set(false);
        abandonedAttemptId = currentAttemptId;
        try {
            Intent homeIntent = new Intent(Intent.ACTION_MAIN);
            homeIntent.addCategory(Intent.CATEGORY_HOME);
            homeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(homeIntent);
        } catch (Exception ignored) {}
    }

    private void showOverlayCoverInternal() {
        try {
            ensureOverlayCreated();
            if (overlayView == null || windowManager == null) return;
            if (overlayWindowAdded) {
                // Already showing from a still-in-flight previous
                // attempt -- don't insert a second window on top of
                // itself.
                overlayView.requestFocus();
                startOverlayWatchdog();
                return;
            }
            windowManager.addView(overlayView, buildOverlayLayoutParams());
            overlayWindowAdded = true;
            overlayView.requestFocus();
            startOverlayWatchdog();
        } catch (Exception ignored) {}
    }

    // ACTION_CLOSE_SYSTEM_DIALOGS fires reliably the instant the user
    // presses home or opens recents -- a context-registered receiver
    // (unlike a manifest one) still gets this on modern Android. This is
    // a fast, event-driven path to dismiss the cover, instead of waiting
    // on the poll loop's own fg-change bookkeeping to catch up.
    private final BroadcastReceiver homePressReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!LockScreenActivity.isShowing && isOverlayCoverShowing()) {
                Log.d("OneLockDebug", "homePressReceiver: dismissing stuck cover");
                lockTriggerInFlight.set(false);
                abandonedAttemptId = currentAttemptId;
                hideOverlayCoverInternal();
            }
        }
    };

    private void registerHomePressReceiver() {
        try {
            IntentFilter filter = new IntentFilter(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
            registerReceiver(homePressReceiver, filter);
        } catch (Exception ignored) {}
    }

    // Belt-and-braces backstop: runs on its own short interval ONLY while
    // the cover is visible, calling getForegroundPackage() directly --
    // completely bypassing handleForegroundCandidate()'s prev/fg diff
    // gating (that gating is what let this get stuck before: it only
    // calls processPackage() when the tracked "prev" value itself
    // changes, which has edge cases). As long as this watchdog is
    // running, a cover that no longer matches reality gets closed within
    // one tick, regardless of what the main poll's bookkeeping thinks.
    private static final long OVERLAY_WATCHDOG_INTERVAL_MS = 100;
    // Decisive, low-latency signal that the user has left the locked app
    // that's pending behind the cover -- regardless of what's now in
    // front (Home/launcher, another app, doesn't matter). An app's own
    // PAUSED event is delivered quickly and reliably by the OS as part
    // of it actually leaving the foreground, unlike waiting to learn
    // what the *next* foreground app is (see the bug this replaces,
    // below).
    private boolean hasPendingLeftForeground(String pending) {
        if (pending == null || pending.isEmpty()) return false;
        try {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
            if (usm == null) return false;
            long now = System.currentTimeMillis();
            UsageEvents events = usm.queryEvents(now - 8000, now + 1000);
            UsageEvents.Event event = new UsageEvents.Event();
            int lastTypeForPending = -1;
            while (events.hasNextEvent()) {
                events.getNextEvent(event);
                if (pending.equals(event.getPackageName())) {
                    int type = event.getEventType();
                    if (type == UsageEvents.Event.ACTIVITY_RESUMED || type == UsageEvents.Event.ACTIVITY_PAUSED) {
                        lastTypeForPending = type;
                    }
                }
            }
            return lastTypeForPending == UsageEvents.Event.ACTIVITY_PAUSED;
        } catch (Exception e) {
            return false;
        }
    }

    private final Runnable overlayWatchdog = new Runnable() {
        @Override
        public void run() {
            if (!isOverlayCoverShowing()) return; // stopped itself already
            try {
                if (!LockScreenActivity.isShowing) {
                    String pending = lastLockedPkg.get();

                    // Check this FIRST. getForegroundPackage() below
                    // silently falls back to returning the last-known
                    // foreground package (which, at this exact moment,
                    // IS `pending`) whenever UsageStatsManager hasn't
                    // yet delivered a fresh event for whatever the user
                    // switched to -- extremely common right after a Home
                    // press/gesture. That made `fg.equals(pending)` look
                    // permanently true and left the cover stuck even
                    // though the app underneath had genuinely already
                    // closed. This check doesn't need to know what's now
                    // in front; it only needs to know `pending` itself
                    // already paused, which is what actually happened.
                    if (hasPendingLeftForeground(pending)) {
                        Log.d("OneLockDebug", "overlayWatchdog: dismissing stuck cover, " + pending + " has paused");
                        lockTriggerInFlight.set(false);
                        abandonedAttemptId = currentAttemptId;
                        hideOverlayCoverInternal();
                        return;
                    }

                    String fg = getForegroundPackage();
                    if (!fg.isEmpty() && (pending == null || !fg.equals(pending))) {
                        Log.d("OneLockDebug", "overlayWatchdog: dismissing stuck cover, real fg=" + fg + " pending=" + pending);
                        lockTriggerInFlight.set(false);
                        abandonedAttemptId = currentAttemptId;
                        hideOverlayCoverInternal();
                        return;
                    }
                }
            } catch (Exception ignored) {}
            mainHandler.postDelayed(this, OVERLAY_WATCHDOG_INTERVAL_MS);
        }
    };

    private void startOverlayWatchdog() {
        mainHandler.removeCallbacks(overlayWatchdog);
        mainHandler.postDelayed(overlayWatchdog, OVERLAY_WATCHDOG_INTERVAL_MS);
    }

    private void stopOverlayWatchdog() {
        mainHandler.removeCallbacks(overlayWatchdog);
    }

    private boolean isOverlayCoverShowing() {
        return overlayWindowAdded;
    }

    private void hideOverlayCoverInternal() {
        stopOverlayWatchdog();
        try {
            if (overlayWindowAdded && windowManager != null && overlayView != null) {
                windowManager.removeView(overlayView);
            }
        } catch (Exception ignored) {
        } finally {
            overlayWindowAdded = false;
        }
    }

    // Tapping the black cover gives the user something deliberate to do
    // instead of the cover just sitting there until a poll cycle or the
    // 12s safety net eventually resolves things on their own. If
    // LockScreenActivity is already genuinely showing, this is a no-op --
    // the tap just lands on it normally. If it's stuck (never launched,
    // or the process is still catching up), this retries the launch.
    private void onOverlayTapped() {
        if (LockScreenActivity.isShowing) return;
        String target = lastLockedPkg.get();
        if (target == null || target.isEmpty()) return;
        Log.d("OneLockDebug", "overlay tapped: retrying launch for " + target);
        lockTriggerInFlight.set(false);
        launchLockScreen(target);
    }

    // Called by LockScreenActivity the moment its own real UI is up, so
    // the handoff from "instant black cover" to "actual lock screen" is
    // seamless, and so the full-screen-intent trigger notification (which
    // has done its job once the Activity is showing) doesn't linger.
    public static void hideOverlayCover() {
        WeakReference<AppLockForegroundService> ref = sInstance;
        AppLockForegroundService instance = ref != null ? ref.get() : null;
        if (instance == null || instance.mainHandler == null) return;
        instance.mainHandler.post(() -> {
            instance.hideOverlayCoverInternal();
            try {
                NotificationManager nm = (NotificationManager) instance.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null) nm.cancel(LOCK_TRIGGER_NOTIF_ID);
            } catch (Exception ignored) {}
        });
    }

    private void launchLockScreen(String targetPkg) {
        if (!lockTriggerInFlight.compareAndSet(false, true)) {
            Log.d("OneLockDebug", "launchLockScreen: BLOCKED, already in flight for " + targetPkg);
            return; // a lock sequence is already mid-flight, don't double-fire
        }
        Log.d("OneLockDebug", "launchLockScreen: firing for " + targetPkg);
        currentAttemptId = lockAttemptCounter.incrementAndGet();
        long thisAttemptId = currentAttemptId;

        // Posted first: the instant black cover, so it's on screen before
        // anything below has a chance to let a stray frame of the target
        // app's content through.
        mainHandler.post(this::showOverlayCoverInternal);

        Intent lockIntent = new Intent(this, LockScreenActivity.class);
        lockIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        lockIntent.putExtra("target_package", targetPkg);
        lockIntent.putExtra("attempt_id", thisAttemptId);
        PendingIntent lockPi = PendingIntent.getActivity(
                this, 3, lockIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        mainHandler.post(() -> {
            // The permanent 1x1 anchor pixel (attached at service start,
            // never removed) keeps this app continuously satisfying the
            // "currently showing an overlay" background-activity-start
            // exemption -- so this no longer races against the visible
            // cover's addView() finishing in time, unlike before.
            try {
                startActivity(lockIntent);
            } catch (Exception ignored) {}

            // Only post this when it's actually needed: a full-screen-
            // intent notification exists to auto-launch its Activity when
            // the screen is off/locked, where startActivity() alone can't
            // reliably reach the user. While the screen is already on
            // (the normal fast-switch case, which is most of the time),
            // startActivity() above already works directly -- posting
            // this too just meant a HIGH-importance banner popped up on
            // every single lock trigger for no reason.
            boolean screenIsOff = !sScreenOn;
            boolean keyguardLocked = false;
            try {
                android.app.KeyguardManager km =
                        (android.app.KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
                keyguardLocked = km != null && km.isKeyguardLocked();
            } catch (Exception ignored) {}

            if (screenIsOff || keyguardLocked) {
                try {
                    Notification n = new Notification.Builder(this, LOCK_TRIGGER_CHANNEL_ID)
                            .setContentTitle("One Lock")
                            .setContentText("Unlock required")
                            .setSmallIcon(R.drawable.vaulticon_small)
                            .setCategory(Notification.CATEGORY_CALL)
                            .setPriority(Notification.PRIORITY_HIGH)
                            .setFullScreenIntent(lockPi, true)
                            .setContentIntent(lockPi)
                            .setAutoCancel(true)
                            .setOngoing(false)
                            .build();
                    NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    if (nm != null) nm.notify(LOCK_TRIGGER_NOTIF_ID, n);

                    // Safety net: hideOverlayCover() (called from
                    // LockScreenActivity.onCreate) is what normally
                    // cancels this. If that Activity is ever slow to
                    // actually start, this guarantees the notification
                    // can't linger indefinitely.
                    mainHandler.postDelayed(() -> {
                        try {
                            NotificationManager nm2 = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                            if (nm2 != null) nm2.cancel(LOCK_TRIGGER_NOTIF_ID);
                        } catch (Exception ignored) {}
                    }, 8000);
                } catch (Exception ignored) {}
            }
        });

        mainHandler.postDelayed(() -> lockTriggerInFlight.set(false), 1500);

        // NOTE: no longer auto-hides the visible cover after a timeout.
        // A black screen that silently disappears on its own is worse
        // than one that stays up -- it can leave the target app exposed
        // with no indication anything went wrong. The cover now only
        // ever goes away when LockScreenActivity actually shows (see
        // hideOverlayCover(), called from its onCreate), or when the
        // user taps it (see onOverlayTapped(), which retries the launch
        // rather than just dismissing). This timer only clears the
        // in-flight flag above so a retry can actually fire; it does not
        // touch the cover's visibility.
    }

    private void refreshLockedAppsCache() {
        if (cacheRefreshing.get()) return;
        cacheRefreshing.set(true);
        try {
            SharedPreferences fp = getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE);
            String raw = fp.getString("flutter.one_lock_locked_apps_json", null);

            lockedSet.clear();
            if (raw != null) {
                int startIdx = raw.indexOf("[");
                if (startIdx != -1) {
                    String cleanJson = raw.substring(startIdx);
                    JSONArray arr = new JSONArray(cleanJson);
                    for (int i = 0; i < arr.length(); i++) {
                        String p = arr.getString(i).trim();
                        if (!p.isEmpty()) lockedSet.add(p);
                    }
                }
            }
            sLockAppsMode  = fp.getString("flutter.one_lock_lock_apps_mode", "immediate");
            sScreenOffMode = fp.getBoolean("flutter.one_lock_unlock_until_screen_off", false);

            lastLockedCacheTime = System.currentTimeMillis();
        } catch (Exception ignored) {
        } finally {
            cacheRefreshing.set(false);
        }
    }

    private boolean isAppLocked(String pkg) {
        if ((System.currentTimeMillis() - lastLockedCacheTime) > LOCKED_CACHE_TTL_MS) {
            refreshLockedAppsCache();
        }
        return lockedSet.contains(pkg);
    }

    // Called for ACTION_REFRESH_LOCK_SETTINGS. Forces an immediate reload
    // of sLockAppsMode/sScreenOffMode (bypassing the lazy TTL) and wipes
    // any per-app grace/screen-off state recorded under whatever setting
    // was active a moment ago -- see the comment on
    // ACTION_REFRESH_LOCK_SETTINGS for why both matter.
    private void forceRefreshLockSettingsAndClearState() {
        lastLockedCacheTime = 0; // guarantees the next line actually reloads
        refreshLockedAppsCache();
        sPerAppGraceExpiry.clear();
        sPerAppUnlockedUntilScreenOff.clear();
    }

    private boolean isLauncherPkg(String pkg) {
        if (pkg == null) return false;
        String l = pkg.toLowerCase();
        if (LAUNCHERS.contains(l)) return true;
        return l.contains("launcher") || l.contains("miui.home") || l.contains("trebuchet");
    }

    // Cached: PackageManager lookups are cheap but not free, and this
    // question's answer for a given package never changes at runtime.
    private final Map<String, Boolean> launchableCache = new java.util.concurrent.ConcurrentHashMap<>();

    private boolean isAppLaunchable(String pkg) {
        Boolean cached = launchableCache.get(pkg);
        if (cached != null) return cached;
        boolean launchable;
        try {
            launchable = getPackageManager().getLaunchIntentForPackage(pkg) != null;
        } catch (Exception e) {
            launchable = false;
        }
        launchableCache.put(pkg, launchable);
        return launchable;
    }

    private boolean isSystemPkg(String pkg) {
        if (pkg == null) return false;
        String l = pkg.toLowerCase();
        if (SYSTEM_PKGS.contains(l)) return true;
        return l.contains("systemui") || l.contains("inputmethod") || l.contains("honeyboard") ||
               l.contains("permissioncontroller") || l.contains("providers.media") ||
               l.contains("documentsui") || l.contains("cocktailbar") || l.contains("com.google.android.as") ||
               l.contains(".gms") || l.contains("bixby") || l.contains("assistant") || l.contains("knox") ||
               // Samsung share/capture/OCR helper surfaces -- transient
               // system UI, never a real app someone locks.
               l.contains("shareui") || l.contains("sharelive") || l.contains("allshare") ||
               l.contains("smartcapture") || l.contains("smartclip") || l.contains("visualsearch") ||
               l.contains("smartsuggestions") ||
               // Knox / device-management background agents -- pure
               // system daemons, not user-facing apps.
               l.contains("authfw") || l.contains("omcagent") || l.contains("soagent") ||
               l.contains("dqagent") || l.contains("kgclient") || l.contains("mdm") ||
               l.contains("scloud") || l.contains("aodservice") ||
               // Biometric framework internals -- our own lock screen's
               // fingerprint prompt can itself transiently surface one of
               // these; exempting them also protects our own flow, not
               // just third-party apps.
               l.contains("biometrics") || l.contains("rubin.app") ||
               l.contains("intellivoiceservice") || l.contains("visionintelligence") ||
               l.contains("clipboard");
    }

    private static boolean isInstallerFamilyPkg(String pkg) {
        if (pkg == null) return false;
        return INSTALLER_FAMILY.contains(pkg.toLowerCase()) || pkg.toLowerCase().contains("packageinstaller");
    }

    // Deliberately does NOT fall back to a ".contains("packageinstaller")"
    // substring match like isInstallerFamilyPkg does -- that broader
    // matching exists there to catch OEM PackageInstaller variants not in
    // the explicit list, which is fine for excursion pass-through, but
    // here we want an exact match against exactly what Uninstall
    // Protection toggles, nothing broader.
    private static boolean isUninstallProtectionPkg(String pkg) {
        if (pkg == null) return false;
        return UNINSTALL_PROTECTION_PKGS.contains(pkg.toLowerCase());
    }

    // Shared by processPackage() and checkSplitScreenLockedApps() so both
    // paths honor the same "Lock Apps: 1 minute" / "Unlock Until Screen
    // Off" per-app persistence. Never true for uninstall-protection
    // packages (the narrow PackageInstaller set) -- those always
    // re-challenge, no exceptions. NOT gated on the broader
    // installer-family flag -- a genuinely locked Settings app must still
    // get normal grace/screen-off behavior.
    // NOTE: does not remove expired grace entries as a side effect when
    // called from the split-screen path (that pruning still only happens
    // in processPackage, which owns the map's lifecycle); this method only
    // reads.
    private static boolean hasPerAppUnlockBypass(String pkg) {
        if (isUninstallProtectionPkg(pkg)) return false;
        Long graceExpiry = sPerAppGraceExpiry.get(pkg);
        if (graceExpiry != null && System.currentTimeMillis() < graceExpiry) return true;
        return sPerAppUnlockedUntilScreenOff.contains(pkg);
    }
}