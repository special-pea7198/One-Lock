package com.onelock.applock;

import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/**
 * AlarmManager watchdog — fires every 15 minutes.
 * Checks if AppLockForegroundService is running.
 * If not, restarts it immediately.
 * This is the final failsafe after START_STICKY,
 * BootReceiver, and battery optimization exemption.
 */
public class WatchdogReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!isServiceRunning(context)) {
            startService(context);
        }
        // Reschedule next watchdog alarm regardless
        WatchdogScheduler.schedule(context);
    }

    private boolean isServiceRunning(Context context) {
        ActivityManager am =
                (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (am == null) return false;
        for (ActivityManager.RunningServiceInfo info :
                am.getRunningServices(Integer.MAX_VALUE)) {
            if (AppLockForegroundService.class.getName()
                    .equals(info.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    private void startService(Context context) {
        try {
            Intent i = new Intent(context, AppLockForegroundService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i);
            } else {
                context.startService(i);
            }
        } catch (Exception ignored) {}
    }
}
