package com.onelock.applock;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

public class OneLockDeviceAdmin extends DeviceAdminReceiver {

    @Override
    public void onEnabled(Context context, Intent intent) {
        // Device admin enabled — uninstall protection active
    }

    @Override
    public CharSequence onDisableRequested(Context context, Intent intent) {
        return "One Lock will no longer protect against uninstall.";
    }

    @Override
    public void onDisabled(Context context, Intent intent) {
        // Admin disabled
    }
}
