package com.onelock.applock;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/**
 * Simple fingerprint-scanner-style icon, drawn procedurally (concentric
 * arcs within a circle) so the app doesn't need to ship/import an
 * external drawable asset. Purely visual -- the actual tap handling
 * lives on the parent LockOverlayView, which already treats a tap
 * anywhere on the black cover as "retry."
 */
public class FingerprintIconView extends View {

    private final Paint ringPaint;
    private final Paint arcPaint;

    public FingerprintIconView(Context context) {
        super(context);

        ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setStrokeWidth(dp(2.5f));
        ringPaint.setColor(0x33FFFFFF); // faint outer ring

        arcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        arcPaint.setStyle(Paint.Style.STROKE);
        arcPaint.setStrokeWidth(dp(3f));
        arcPaint.setStrokeCap(Paint.Cap.ROUND);
        arcPaint.setColor(0xCCFFFFFF); // brighter fingerprint ridges
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float maxR = Math.min(cx, cy) - dp(4f);

        // Outer faint circle (the "sensor" boundary)
        canvas.drawCircle(cx, cy, maxR, ringPaint);

        // A few concentric open arcs to suggest a fingerprint ridge
        // pattern, each rotated slightly so it doesn't look like a
        // plain bullseye.
        int rings = 3;
        for (int i = 0; i < rings; i++) {
            float r = maxR * (0.45f + i * 0.22f);
            RectF rect = new RectF(cx - r, cy - r, cx + r, cy + r);
            float startAngle = -200f + (i * 15f);
            float sweep = 220f - (i * 10f);
            canvas.drawArc(rect, startAngle, sweep, false, arcPaint);
        }
    }
}
