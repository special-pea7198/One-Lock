# One Lock — Developer Setup Guide

## Project Structure

```
one_lock/
├── lib/
│   ├── main.dart                    # Entry point
│   ├── screens/
│   │   ├── setup_mpin_screen.dart   # First launch MPIN setup
│   │   ├── auth_gate_screen.dart    # App open authentication
│   │   └── home_screen.dart         # Main app list + search
│   └── services/
│       ├── auth_service.dart        # Biometric + MPIN logic
│       └── app_lock_service.dart    # Locked apps storage
├── android/app/src/main/
│   ├── AndroidManifest.xml
│   ├── java/com/onelock/applock/
│   │   ├── AppLockAccessibilityService.java  # Core monitor
│   │   ├── LockScreenActivity.java           # Native biometric popup
│   │   ├── BootReceiver.java                 # Auto-restart
│   │   └── OneLockDeviceAdmin.java           # Uninstall protection
│   └── res/
│       ├── xml/accessibility_service_config.xml
│       ├── xml/device_admin.xml
│       └── layout/activity_lock_screen.xml
└── pubspec.yaml
```

## Prerequisites

1. Install Flutter: https://docs.flutter.dev/get-started/install
2. Install Android Studio
3. Install Java 17+
4. Connect a Samsung Android device (Android 10+)

## Setup Steps

### 1. Get dependencies
```bash
cd one_lock
flutter pub get
```

### 2. Add app icon
Place your icon PNG at: `assets/icon.png`
Run: `flutter pub run flutter_launcher_icons`
(Add flutter_launcher_icons to pubspec.yaml dev_dependencies first)

### 3. Add missing string resource
In `android/app/src/main/res/values/strings.xml` add:
```xml
<string name="accessibility_service_description">
  One Lock monitors app launches to protect your locked apps.
</string>
```

### 4. Add androidx.biometric dependency
In `android/app/build.gradle` inside dependencies:
```gradle
implementation 'androidx.biometric:biometric:1.1.0'
implementation 'androidx.fragment:fragment:1.5.7'
```

### 5. Update build.gradle
```gradle
android {
    compileSdkVersion 34
    defaultConfig {
        applicationId "com.onelock.applock"
        minSdkVersion 23
        targetSdkVersion 34
    }
}
```

### 6. Build & run
```bash
flutter run
```

### 7. First launch on device
After installing, the user must:
a) Set their MPIN (6 digits)
b) Go to Settings → Accessibility → One Lock → Enable
c) Optionally activate Device Admin for uninstall protection

## How It Works

### App Locking Flow
1. `AppLockAccessibilityService` monitors every window change
2. When a locked app opens, `LockScreenActivity` launches instantly
3. `LockScreenActivity` shows the native Samsung BiometricPrompt
4. On success → finish() → locked app is visible
5. On cancel → user is sent to home screen

### Authentication Options
- **Fingerprint**: via BiometricPrompt (Samsung fingerprint sensor)
- **Face**: via BiometricPrompt (Samsung face recognition)
- **MPIN**: via in-app 6-digit PIN dialog (stored encrypted)

### Uninstall Protection
- App registers as Device Admin
- To uninstall, user must deactivate Device Admin first
- Deactivation requires biometric OR MPIN confirmation

## Samsung-Only Restriction
In Play Store listing:
- Go to Release → App bundle explorer
- Device catalog → Filter to Samsung only
OR
- In store listing, set "Supported devices" to Samsung

## Known Limitations
- Android may show system PIN/pattern as last resort after 5 failed biometrics (OS behavior, cannot be overridden)
- Accessibility service may be killed by aggressive battery optimization — guide users to disable battery optimization for One Lock
- On Android 12+, usage of SYSTEM_ALERT_WINDOW requires extra user permission step

## Play Store Notes
- App needs "Special app access" permissions disclosure
- Accessibility service requires privacy policy
- Package name: com.onelock.applock

---

## Actual Current Architecture (see this section, not the legacy notes above)

The sections above describe an earlier design. This is what the app
actually does today.

### Detection
`UsageStatsManager` polling (`AppLockForegroundService`) is the only
detection mechanism. Polls every 150ms while the screen is on, 1500ms
while it's off, asking `UsageEvents` for the most recent
`ACTIVITY_RESUMED` event.

Known limitation: `UsageStatsManager` events can be delayed by OS-level
battery-optimization batching on some OEMs (Samsung, Xiaomi especially),
which can show up as an occasional lag on very fast app-to-app switches.
This is a platform-level constraint on this detection method, not a bug
in the polling logic itself.

### Instant lock cover
The moment a lock decision is made, `AppLockForegroundService` shows a
`WindowManager` overlay (`LockOverlayView`, `TYPE_APPLICATION_OVERLAY`) --
a plain black, non-interactive view added directly to the window
manager, not an Activity. This appears without the latency of an
Activity launch, and is handed off to `LockScreenActivity` (which hosts
the actual `BiometricPrompt`, since biometric auth requires a
`FragmentActivity`) the instant that Activity's real UI is up.

### Screen-adaptive power use
A `BroadcastReceiver` for `ACTION_SCREEN_ON`/`ACTION_SCREEN_OFF` in
`AppLockForegroundService` throttles both the polling interval (150ms →
1500ms) and the `WatchdogScheduler` restart-check interval (15 min → 30
min) while the screen is off, since nothing is switchable while the
screen is dark.

### Split-screen
A secondary, additive check (`checkSplitScreenLockedApps`) scans for any
locked package whose most recent event is `ACTIVITY_RESUMED` but isn't
the "primary" foreground package -- covers the case where a locked app
is visible in one split-screen pane while the user is interacting with
the other.
