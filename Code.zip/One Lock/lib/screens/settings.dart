import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/app_lock_service.dart';

// ── GLOBAL NOTIFIER: Plugs into main.dart to instantly change the whole app UI ──
final ValueNotifier<ThemeMode> appThemeNotifier = ValueNotifier(ThemeMode.system);

const String _kLockAppsModeKey = 'one_lock_lock_apps_mode'; // 'immediate' | '1min'
const String _kScreenOffUnlockKey = 'one_lock_unlock_until_screen_off'; // bool

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  static const _channel = MethodChannel('com.onelock.applock/apps');

  final ScrollController _scrollController = ScrollController();
  double _scrollOffset = 0.0;

  String _selectedTheme = 'Match system';

  bool _allAppsLockEnabled = true;
  String _lockAppsMode = 'immediate'; 
  bool _screenOffUnlock = false;

  @override
  void initState() {
    super.initState();

    // NOTE: Deliberately NOT calling SystemChrome.setEnabledSystemUIMode here.
    // HomeScreen already puts the app in SystemUiMode.manual (status bar hidden)
    // and stays mounted underneath this screen the whole time it's pushed, so
    // that mode is already in effect. Flipping the system UI mode again on
    // entry/exit was what broke the predictive-back slide animation and added
    // a delay when popping back to Home — the OS invalidates its back-gesture
    // preview when the system bar/inset configuration changes mid-transition.

    _loadThemePersistence();
    _loadLockSettings();
    _scrollController.addListener(() {
      setState(() {
        _scrollOffset = _scrollController.offset;
      });
    });
  }

  @override
  void dispose() {
    // NOTE: Deliberately NOT restoring SystemUiMode.edgeToEdge here either.
    // Home controls its own system UI mode in its own initState/dispose;
    // this screen no longer touches it at all, in either direction.

    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _loadThemePersistence() async {
    final prefs = await SharedPreferences.getInstance();
    final savedTheme = prefs.getString('app_theme_mode') ?? 'Match system';

    if (mounted) {
      setState(() {
        _selectedTheme = savedTheme;
      });
    }

    if (savedTheme == 'Dark') {
      appThemeNotifier.value = ThemeMode.dark;
    } else if (savedTheme == 'Light') {
      appThemeNotifier.value = ThemeMode.light;
    } else {
      appThemeNotifier.value = ThemeMode.system;
    }
  }

  Future<void> _saveThemePersistence(String themeMode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('app_theme_mode', themeMode);

    setState(() {
      _selectedTheme = themeMode;
    });

    if (themeMode == 'Dark') {
      appThemeNotifier.value = ThemeMode.dark;
    } else if (themeMode == 'Light') {
      appThemeNotifier.value = ThemeMode.light;
    } else {
      appThemeNotifier.value = ThemeMode.system;
    }
  }

  Future<void> _loadLockSettings() async {
    bool lockingEnabled = true;
    try {
      lockingEnabled = await _channel.invokeMethod('getLockingEnabled') as bool? ?? true;
    } catch (_) {}

    final prefs = await SharedPreferences.getInstance();
    final mode = prefs.getString(_kLockAppsModeKey) ?? 'immediate';
    final screenOff = prefs.getBool(_kScreenOffUnlockKey) ?? false;

    if (mounted) {
      setState(() {
        _allAppsLockEnabled = lockingEnabled;
        _lockAppsMode = mode;
        _screenOffUnlock = mode == '1min' ? false : screenOff;
      });
    }
  }

  Future<void> _setAllAppsLockEnabled(bool enabled) async {
    setState(() {
      _allAppsLockEnabled = enabled;
    });
    try {
      await _channel.invokeMethod('setLockingEnabled', {'enabled': enabled});
    } catch (_) {}
  }

  Future<void> _setLockAppsMode(String mode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kLockAppsModeKey, mode);

    setState(() {
      _lockAppsMode = mode;
      if (mode == '1min') {
        _screenOffUnlock = false;
      }
    });

    if (mode == '1min') {
      await prefs.setBool(_kScreenOffUnlockKey, false);
    }

    try {
      await _channel.invokeMethod('refreshLockSettings');
    } catch (_) {}
  }

  Future<void> _setScreenOffUnlock(bool enabled) async {
    if (_lockAppsMode == '1min') return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kScreenOffUnlockKey, enabled);
    setState(() {
      _screenOffUnlock = enabled;
    });

    try {
      await _channel.invokeMethod('refreshLockSettings');
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    
    // One UI background & text colors
    final Color scaffoldBg = isDark ? const Color(0xFF000000) : const Color(0xFFF2F2F7);
    final Color vignetteColor = scaffoldBg;
    final Color textColor = isDark ? Colors.white : const Color(0xFF1C1C1E);

    // Gradient opacities matching HomeScreen/AboutScreen
    final double gradientCoreOpacity = isDark ? 0.28 : 0.30;
    final double gradientEdgeOpacity = isDark ? 0.08 : 0.10;

    // Solid One UI styled card containers (no border, no shadow)
    final Color panelColor = isDark ? const Color(0xFF171719) : Colors.white;
    final Color sectionTitleColor = isDark ? Colors.white : const Color(0xFF1C1C1E);
    
    // One UI row divider
    final Color rowDividerColor = isDark ? const Color(0xFF28282B) : const Color(0xFFE5E5EA);
    
    // Back button floating styling
    final Color backButtonColor = isDark 
        ? const Color(0xFF232326).withOpacity(0.96) 
        : Colors.white.withOpacity(0.96);
    final Color backButtonShadowColor = isDark 
        ? Colors.black.withOpacity(0.40) 
        : Colors.black.withOpacity(0.08);
    final Color backIconColor = isDark ? Colors.white70 : const Color(0xFF636366);

    // Dynamic Bottom Inset Calculation
    final double bottomInset = MediaQuery.of(context).padding.bottom;
    final double gradientHeight = 120.0 + bottomInset;

    // Fade just the text, NOT the blur
    double titleOpacity = 1.0 - (_scrollOffset / 80.0);
    if (titleOpacity < 0.0) titleOpacity = 0.0;
    if (titleOpacity > 1.0) titleOpacity = 1.0;

    final bool lockModeIsOneMin = _lockAppsMode == '1min';

    return Scaffold(
      backgroundColor: scaffoldBg,
      body: Stack(
        children: [
          // ── LAYER 1: STATIC RADIAL BLUR ──
          Positioned(
            top: -120,
            left: -50,
            right: -50,
            child: Center(
              child: Container(
                width: 600,
                height: 600,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      const Color(0xFF3D8EFF).withOpacity(gradientCoreOpacity),
                      const Color(0xFF3D8EFF).withOpacity(gradientEdgeOpacity),
                      Colors.transparent,
                    ],
                    stops: const [0.0, 0.50, 1.0],
                  ),
                ),
              ),
            ),
          ),

          // ── LAYER 2: FADING TITLE ──
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(24, 110, 24, 0),
                child: Align(
                  alignment: Alignment.center,
                  child: IgnorePointer(
                    child: Opacity(
                      opacity: titleOpacity,
                      child: Text(
                        'Settings',
                        style: TextStyle(
                          fontFamily: 'LemonMilk',
                          fontSize: 44,
                          fontWeight: FontWeight.w800,
                          color: textColor,
                          letterSpacing: -1.2,
                          height: 1.1,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),

          // ── LAYER 3: LISTVIEW ──
          Padding(
            padding: const EdgeInsets.only(top: 0),
            child: ListView(
              controller: _scrollController,
              // Increased bottom padding dramatically so the list can scroll higher up into the empty region
              padding: EdgeInsets.fromLTRB(16, 260, 16, 200 + bottomInset),
              physics: const BouncingScrollPhysics(),
              children: [
                // 1. ── App Lock Toggle (Main Off/On) ──
                _buildPanel(
                  panelColor: panelColor,
                  title: 'App Lock',
                  titleColor: sectionTitleColor,
                  textColor: textColor,
                  children: [
                    _buildSwitchRow(
                      title: _allAppsLockEnabled ? 'Enabled' : 'Disabled',
                      subtitle: null,
                      value: _allAppsLockEnabled,
                      onChanged: _setAllAppsLockEnabled,
                      textColor: textColor,
                      bottomBorderColor: Colors.transparent,
                      isDark: isDark,
                    ),
                  ],
                ),

                const SizedBox(height: 16),

                // 2. ── App Theme ──
                _buildPanel(
                  panelColor: panelColor,
                  title: 'App Theme',
                  titleColor: sectionTitleColor,
                  textColor: textColor,
                  children: [
                    _buildThemeSelectionRow('Match system', _selectedTheme == 'Match system', rowDividerColor, textColor),
                    _buildThemeSelectionRow('Dark', _selectedTheme == 'Dark', rowDividerColor, textColor),
                    _buildThemeSelectionRow('Light', _selectedTheme == 'Light', Colors.transparent, textColor),
                  ],
                ),

                const SizedBox(height: 16),

                // 3. ── Lock Apps ──
                _buildPanel(
                  panelColor: panelColor,
                  title: 'Lock Apps',
                  titleColor: sectionTitleColor,
                  textColor: textColor,
                  children: [
                    _buildLockModeRow(
                      'Immediately',
                      'immediate',
                      _lockAppsMode == 'immediate',
                      rowDividerColor,
                      textColor,
                    ),
                    _buildLockModeRow(
                      'After 1 minute',
                      '1min',
                      _lockAppsMode == '1min',
                      Colors.transparent,
                      textColor,
                    ),
                  ],
                ),

                const SizedBox(height: 16),

                // 4. ── Screen-Off Unlock ──
                _buildPanel(
                  panelColor: panelColor,
                  title: 'Screen-Off Unlock', 
                  titleColor: lockModeIsOneMin ? sectionTitleColor.withOpacity(0.35) : sectionTitleColor,
                  textColor: textColor,
                  children: [
                    _buildSwitchRow(
                      title: 'An unlocked app stays open until you lock your phone',
                      subtitle: null,
                      value: _screenOffUnlock,
                      onChanged: lockModeIsOneMin ? null : _setScreenOffUnlock,
                      textColor: textColor,
                      bottomBorderColor: Colors.transparent,
                      disabled: lockModeIsOneMin,
                      isDark: isDark,
                      isSubOption: true,
                    ),
                  ],
                ),
              ],
            ),
          ),

          // ── LAYER 4: ENHANCED TOP VIGNETTE GRADIENT ──
          Positioned(
            left: 0,
            right: 0,
            top: 0,
            height: 70,
            child: RepaintBoundary(
              child: IgnorePointer(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        vignetteColor.withOpacity(1.0),
                        vignetteColor.withOpacity(0.6),
                        vignetteColor.withOpacity(0.0),
                      ],
                      stops: const [0.0, 0.45, 1.0],
                    ),
                  ),
                ),
              ),
            ),
          ),

          // ── LAYER 5: BOTTOM VIGNETTE GRADIENT ──
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            height: gradientHeight,
            child: RepaintBoundary(
              child: IgnorePointer(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        vignetteColor.withOpacity(0.0),
                        vignetteColor.withOpacity(1.0),
                      ],
                      stops: const [0.0, 1.0],
                    ),
                  ),
                ),
              ),
            ),
          ),

          // ── LAYER 6: FLOATING BACK BUTTON ──
          Positioned(
            top: 36, 
            left: 16,
            child: GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: backButtonColor,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: backButtonShadowColor,
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.only(right: 2.0), // Optical centering
                  child: Icon(
                    Icons.arrow_back_ios_new,
                    color: backIconColor,
                    size: 20,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPanel({
    required Color panelColor,
    String? title,
    Color? titleColor,
    required Color textColor,
    required List<Widget> children,
  }) {
    return Material(
      color: panelColor,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(28),
        // Removed border completely to match One UI
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (title != null && title.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 8),
              child: Text(
                title,
                style: TextStyle(
                  fontFamily: 'LemonMilk',
                  fontSize: 18, 
                  fontWeight: FontWeight.w800, // Matched boldness
                  color: titleColor ?? textColor,
                ),
              ),
            )
          else
            const SizedBox(height: 12),
          
          ...children,
        ],
      ),
    );
  }

  Widget _buildThemeSelectionRow(String title, bool isSelected, Color bottomBorderColor, Color textColor) {
    return Stack(
      children: [
        ListTile(
          onTap: () => _saveThemePersistence(title),
          contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 2),
          title: Text(
            title,
            style: TextStyle(
              fontFamily: 'LemonMilk',
              fontSize: 14,
              fontWeight: FontWeight.w400, // Lighter item text
              color: textColor.withOpacity(0.8),
            ),
          ),
          trailing: isSelected
              ? const Icon(Icons.check_circle, color: Color(0xFF3D8EFF), size: 22)
              : Icon(Icons.circle_outlined, color: textColor.withOpacity(0.3), size: 22),
        ),
        Positioned(
          bottom: 0,
          left: 24,
          right: 24,
          child: Container(
            height: 1,
            color: bottomBorderColor,
          ),
        ),
      ],
    );
  }

  Widget _buildLockModeRow(
    String title,
    String modeValue,
    bool isSelected,
    Color bottomBorderColor,
    Color textColor,
  ) {
    return Stack(
      children: [
        ListTile(
          onTap: () => _setLockAppsMode(modeValue),
          contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 2),
          title: Text(
            title,
            style: TextStyle(
              fontFamily: 'LemonMilk',
              fontSize: 14,
              fontWeight: FontWeight.w400, // Lighter item text
              color: textColor.withOpacity(0.8),
            ),
          ),
          trailing: isSelected
              ? const Icon(Icons.check_circle, color: Color(0xFF3D8EFF), size: 22)
              : Icon(Icons.circle_outlined, color: textColor.withOpacity(0.3), size: 22),
        ),
        Positioned(
          bottom: 0,
          left: 24,
          right: 24,
          child: Container(
            height: 1,
            color: bottomBorderColor,
          ),
        ),
      ],
    );
  }

  Widget _buildSwitchRow({
    required String title,
    String? subtitle,
    required bool value,
    required ValueChanged<bool>? onChanged,
    required Color textColor,
    required Color bottomBorderColor,
    required bool isDark,
    bool disabled = false,
    bool isSubOption = false,
  }) {
    final Color effectiveOptionColor = disabled 
        ? textColor.withOpacity(0.35) 
        : textColor.withOpacity(0.8); // Matched text clarity

    final Color inactiveTrackColor = isDark ? const Color(0xFF38383A) : const Color(0xFFE5E5EA);

    return Stack(
      children: [
        ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 2),
          title: Text(
            title,
            style: TextStyle(
              fontFamily: 'LemonMilk',
              fontSize: 14,
              fontWeight: FontWeight.w400, // Lighter item text
              color: effectiveOptionColor,
            ),
          ),
          subtitle: subtitle != null
              ? Padding(
                  padding: const EdgeInsets.only(top: 2.0),
                  child: Text(
                    subtitle,
                    style: TextStyle(
                      fontFamily: 'LemonMilk',
                      fontSize: 11,
                      fontWeight: FontWeight.w400,
                      color: disabled ? textColor.withOpacity(0.25) : textColor.withOpacity(0.5),
                    ),
                  ),
                )
              : null,
          trailing: Transform.scale(
            scale: 0.72, // Size matched to HomeScreen
            child: Switch(
              value: value,
              onChanged: disabled ? null : onChanged,
              activeColor: Colors.white,
              activeTrackColor: const Color(0xFF3D8EFF),
              inactiveThumbColor: Colors.white,
              inactiveTrackColor: inactiveTrackColor,
              // Fixed thumb styling for uniform size
              thumbIcon: WidgetStateProperty.resolveWith<Icon?>((states) => const Icon(null)),
              trackOutlineColor: WidgetStateProperty.resolveWith<Color>((states) {
                return Colors.transparent; 
              }),
              trackOutlineWidth: WidgetStateProperty.all(0.0),
            ),
          ),
        ),
        Positioned(
          bottom: 0,
          left: 24,
          right: 24,
          child: Container(
            height: 1,
            color: bottomBorderColor,
          ),
        ),
      ],
    );
  }
}