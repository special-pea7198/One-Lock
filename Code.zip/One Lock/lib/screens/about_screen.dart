import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    // One UI background & text colors
    final Color scaffoldBg = isDark ? const Color(0xFF000000) : const Color(0xFFF2F2F7);
    final Color textColor = isDark ? Colors.white : const Color(0xFF1C1C1E);

    // One UI back button surface (no border, matched to Floating Search Bar / Buttons)
    final Color backButtonColor = isDark
        ? const Color(0xFF232326).withOpacity(0.96)
        : Colors.white.withOpacity(0.96);
    final Color backButtonShadowColor = isDark
        ? Colors.black.withOpacity(0.40)
        : Colors.black.withOpacity(0.08);
    final Color backIconColor = isDark ? Colors.white70 : const Color(0xFF636366);

    // Dynamic Bottom Inset Calculation for 3-button or Gesture Navigation
    final double bottomInset = MediaQuery.of(context).padding.bottom;

    // Gradient opacities matching HomeScreen
    final double gradientCoreOpacity = isDark ? 0.28 : 0.30;
    final double gradientEdgeOpacity = isDark ? 0.08 : 0.10;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        systemNavigationBarColor: Colors.transparent,
        systemNavigationBarDividerColor: Colors.transparent,
        systemNavigationBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
        systemNavigationBarContrastEnforced: false,
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
        statusBarBrightness: isDark ? Brightness.dark : Brightness.light,
        systemStatusBarContrastEnforced: false,
      ),
      child: Scaffold(
        backgroundColor: scaffoldBg,
        body: Stack(
          children: [
            // ── LAYER 1: THE BLUE SPHERE ──
            Positioned.fill(
              child: Center(
                child: Container(
                  width: 800,
                  height: 800, 
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        const Color(0xFF3D8EFF).withOpacity(gradientCoreOpacity),
                        const Color(0xFF3D8EFF).withOpacity(gradientEdgeOpacity),
                        scaffoldBg.withOpacity(0.0),
                      ],
                      stops: const [0.0, 0.50, 1.0],
                    ),
                  ),
                ),
              ),
            ),

            // ── LAYER 2: THE BACK ARROW (One UI Matched) ──
            Positioned(
              top: 36, 
              left: 16,
              child: GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: backButtonColor,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: backButtonShadowColor,
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.only(right: 2.0), // Optical centering
                    child: Icon(
                      Icons.arrow_back_ios_new,
                      color: backIconColor,
                      size: 20,
                    ),
                  ),
                ),
              ),
            ),

            // ── LAYER 3: CENTER TEXT ──
            Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'One Lock',
                    style: TextStyle(
                      fontFamily: 'LemonMilk',
                      fontSize: 46,
                      fontWeight: FontWeight.w800,
                      color: textColor,
                      letterSpacing: -1.2,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    '©2026-2027',
                    style: TextStyle(
                      fontFamily: 'LemonMilk',
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: textColor,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'All rights reserved',
                    style: TextStyle(
                      fontFamily: 'LemonMilk',
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      color: textColor.withOpacity(0.9),
                    ),
                  ),
                ],
              ),
            ),

            // ── LAYER 4: BOTTOM TEXT ──
            Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: EdgeInsets.only(bottom: 24.0 + bottomInset),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'v1.0.0',
                      style: TextStyle(
                        fontFamily: 'LemonMilk',
                        fontSize: 13,
                        fontWeight: FontWeight.w400,
                        color: textColor.withOpacity(0.5),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '-by u/Special-Pea7198',
                      style: TextStyle(
                        fontFamily: 'LemonMilk',
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: textColor.withOpacity(0.5),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}