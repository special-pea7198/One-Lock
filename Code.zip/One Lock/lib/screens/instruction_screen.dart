import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class InstructionScreen extends StatefulWidget {
  const InstructionScreen({Key? key}) : super(key: key);

  @override
  State<InstructionScreen> createState() => _InstructionScreenState();
}

class _InstructionScreenState extends State<InstructionScreen>
    with WidgetsBindingObserver {
  static const platform = MethodChannel('com.onelock.applock/apps');

  bool _waitingForUsageStats = false;
  bool _waitingForOverlay    = false;
  bool _waitingForBattery    = false;
  int  _currentStep          = 0; // 0=notification, 1=usagestats, 2=overlay, 3=battery
  bool _isButtonPressed      = false; // Controls button shrink effect

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      // Step 0 — request notification permission immediately
      await platform.invokeMethod('requestNotification');
      if (mounted) setState(() => _currentStep = 1);
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _handleResumed();
  }

  Future<void> _handleResumed() async {
    if (_waitingForUsageStats) {
      final bool ok = await platform.invokeMethod('hasUsageStats') ?? false;
      if (ok && mounted) {
        _waitingForUsageStats = false;
        setState(() => _currentStep = 2);
      }
      return;
    }
    if (_waitingForOverlay) {
      final bool ok = await platform.invokeMethod('hasOverlayPermission') ?? false;
      if (ok && mounted) {
        _waitingForOverlay = false;
        setState(() => _currentStep = 3);
      }
      return;
    }
    if (_waitingForBattery) {
      // Whether or not they granted battery opt, move to home
      _waitingForBattery = false;
      _goHome();
    }
  }

  Future<void> _onProceedClicked() async {
    if (_currentStep == 1) {
      // ── Step 1: Usage Stats ──
      final bool hasUsage = await platform.invokeMethod('hasUsageStats') ?? false;
      if (hasUsage) {
        setState(() => _currentStep = 2);
      } else {
        _waitingForUsageStats = true;
        await platform.invokeMethod('requestUsageStats');
      }
    } else if (_currentStep == 2) {
      // ── Step 2: Appear on Top (Overlay) ──
      final bool hasOverlay = await platform.invokeMethod('hasOverlayPermission') ?? false;
      if (hasOverlay) {
        setState(() => _currentStep = 3);
      } else {
        _waitingForOverlay = true;
        await platform.invokeMethod('requestOverlayPermission');
      }
    } else if (_currentStep == 3) {
      // ── Step 3: Battery Optimization ──
      final bool isOptimized =
          await platform.invokeMethod('isBatteryOptimized') ?? false;
      if (!isOptimized) {
        _goHome();
      } else {
        _waitingForBattery = true;
        await platform.invokeMethod('requestBatteryOptimization');
      }
    }
  }

  void _goHome() => Navigator.pushReplacementNamed(context, '/home');

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    // One UI background & text colors
    final Color scaffoldBg = isDark ? const Color(0xFF000000) : const Color(0xFFF2F2F7);
    final Color textColor  = isDark ? Colors.white : const Color(0xFF1C1C1E);
    final Color bodyColor  = isDark ? Colors.white70 : const Color(0xFF3C3C43);
    
    // Matched to HomeScreen search bar styling (no blue text in Light mode)
    final Color pillColor = isDark
        ? const Color(0xFF232326).withOpacity(0.96)
        : Colors.white.withOpacity(0.96);
    final Color pillTextColor = isDark ? Colors.white : const Color(0xFF1C1C1E);
    final Color pillShadowColor = isDark
        ? Colors.black.withOpacity(0.40)
        : Colors.black.withOpacity(0.08);

    // Gradient opacities matching HomeScreen
    final double gradientCoreOpacity = isDark ? 0.28 : 0.30;
    final double gradientEdgeOpacity = isDark ? 0.08 : 0.10;

    // Dynamic Bottom Inset Calculation
    final double bottomInset = MediaQuery.of(context).padding.bottom;

    String instructions;
    String buttonLabel;
    if (_currentStep == 0) {
      instructions = '1. Allow Notification permission.\n\n'
                     '2. Enable Usage Data Access.\n\n'
                     '3. Allow Display Over Other Apps.\n\n'
                     '4. Disable battery optimization.';
      buttonLabel = 'Proceed';
    } else if (_currentStep == 1) {
      instructions = 'Step 1 of 3\n\n'
                     'Enable Usage Data Access so\n'
                     'One Lock can detect which\n'
                     'app is in the foreground.';
      buttonLabel = 'Enable Usage Access';
    } else if (_currentStep == 2) {
      instructions = 'Step 2 of 3\n\n'
                     'Allow Display Over Other Apps\n'
                     'so One Lock can securely draw\n'
                     'the lock screen over your apps.';
      buttonLabel = 'Allow Display Over Apps';
    } else {
      instructions = 'Step 3 of 3\n\n'
                     'Disable battery optimization\n'
                     'so One Lock stays active in\n'
                     'the background at all times.\n\n'
                     'You can skip this but the app\n'
                     'may stop working randomly.';
      buttonLabel = 'Disable Optimization';
    }

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        systemNavigationBarColor: Colors.transparent,
        systemNavigationBarDividerColor: Colors.transparent,
        systemNavigationBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
        systemNavigationBarContrastEnforced: false,
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
        statusBarBrightness: isDark ? Brightness.dark : Brightness.light,
        systemStatusBarContrastEnforced: false,
      ),
      child: Scaffold(
        backgroundColor: scaffoldBg,
        body: Stack(
          children: [
            // Background Sphere
            Positioned(
              top: -120, left: -50, right: -50,
              child: RepaintBoundary(
                child: Center(
                  child: Container(
                    width: 600, height: 600,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          const Color(0xFF3D8EFF).withOpacity(gradientCoreOpacity),
                          const Color(0xFF3D8EFF).withOpacity(gradientEdgeOpacity),
                          Colors.transparent,
                        ],
                        stops: const [0.0, 0.50, 1.0],
                      ),
                    ),
                  ),
                ),
              ),
            ),

            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SafeArea(
                  bottom: false,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(24, 110, 24, 0),
                    child: Align(
                      alignment: Alignment.center,
                      child: Text(
                        'One Lock',
                        style: TextStyle(
                          fontFamily: 'LemonMilk',
                          fontSize: 44,
                          fontWeight: FontWeight.w800,
                          color: textColor,
                          letterSpacing: -1.2,
                          height: 1.1,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 100),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 40.0),
                  child: Text(
                    instructions,
                    style: TextStyle(
                      color: bodyColor,
                      fontSize: 16,
                      fontFamily: 'LemonMilk',
                      height: 1.6,
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
                const Spacer(),
              ],
            ),

            // Skip button for battery step (Step 3)
            if (_currentStep == 3)
              Positioned(
                right: 24,
                bottom: 70 + bottomInset,
                child: TextButton(
                  onPressed: _goHome,
                  child: Text(
                    'Skip',
                    style: TextStyle(
                      fontFamily: 'LemonMilk',
                      fontSize: 13,
                      color: bodyColor,
                    ),
                  ),
                ),
              ),

            // Proceed button matched to Floating Search Bar design
            Positioned(
              left: 70, right: 70, bottom: 20 + bottomInset,
              child: RepaintBoundary(
                child: GestureDetector(
                  onTapDown: (_) => setState(() => _isButtonPressed = true),
                  onTapUp: (_) => setState(() => _isButtonPressed = false),
                  onTapCancel: () => setState(() => _isButtonPressed = false),
                  onTap: _onProceedClicked,
                  child: TweenAnimationBuilder<double>(
                    duration: const Duration(milliseconds: 120),
                    curve: Curves.easeOutCubic,
                    tween: Tween<double>(
                      begin: 1.0,
                      end: _isButtonPressed ? 0.93 : 1.0,
                    ),
                    builder: (context, scale, child) {
                      return Transform.scale(
                        scale: scale,
                        child: child,
                      );
                    },
                    child: Container(
                      height: 56,
                      decoration: BoxDecoration(
                        color: pillColor,
                        borderRadius: BorderRadius.circular(28),
                        boxShadow: [
                          BoxShadow(
                            color: pillShadowColor,
                            blurRadius: 18,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        buttonLabel,
                        style: TextStyle(
                          fontFamily: 'LemonMilk',
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: pillTextColor,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}