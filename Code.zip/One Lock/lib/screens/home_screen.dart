import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:dynamic_color/dynamic_color.dart';
import '../services/app_lock_service.dart';
import 'settings.dart'; 

class AppInfo {
  final String packageName;
  final String appName;
  final Uint8List? icon;
  AppInfo({required this.packageName, required this.appName, this.icon});
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const _channel = MethodChannel('com.onelock.applock/apps');
  List<AppInfo> _allApps = [];
  List<AppInfo> _filteredApps = [];
  Set<String> _lockedApps = {};
  bool _loading = true;
  
  bool _isSearchFocused = false;
  bool _wasKeyboardOpen = false;

  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocus = FocusNode();

  final ScrollController _scrollController = ScrollController();
  final ValueNotifier<double> _scrollOffsetNotifier = ValueNotifier(0.0);

  final Map<String, MemoryImage> _iconCache = {};
  String _searchText = '';

  int get _lockedCount {
    int count = 0;
    bool hasInstaller = false;
    for (final pkg in _lockedApps) {
      if (pkg == 'com.android.packageinstaller' || 
          pkg == 'com.samsung.android.packageinstaller' || 
          pkg == 'com.google.android.packageinstaller') {
        hasInstaller = true;
      } else {
        count++;
      }
    }
    return count + (hasInstaller ? 1 : 0);
  }

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

    _loadApps();
    _searchController.addListener(_onSearch);
    
    _scrollController.addListener(() {
      _scrollOffsetNotifier.value = _scrollController.offset;
    });

    _searchFocus.addListener(() {
      if (mounted) {
        setState(() {
          _isSearchFocused = _searchFocus.hasFocus;
        });

        if (_searchFocus.hasFocus && _scrollController.hasClients) {
          _scrollController.animateTo(
            50.0,
            duration: const Duration(milliseconds: 300), 
            curve: Curves.easeOutCubic,
          );
        } else if (!_searchFocus.hasFocus && _scrollController.hasClients) {
          _scrollController.animateTo(
            0.0, 
            duration: const Duration(milliseconds: 300), 
            curve: Curves.easeOutCubic,
          );
        }
      }
    });
  }

  @override
  void dispose() {
    // Restore normal system UI edge-to-edge when leaving the home screen
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    _searchController.dispose();
    _searchFocus.removeListener(() {}); 
    _searchFocus.dispose();
    _scrollController.dispose();
    _scrollOffsetNotifier.dispose();
    super.dispose();
  }

  Future<void> _loadApps() async {
    try {
      final List<dynamic> apps = await _channel.invokeMethod('getInstalledApps');
      final List<AppInfo> appList = apps.map((app) {
        final map = Map<String, dynamic>.from(app);
        return AppInfo(
          packageName: map['packageName'] as String,
          appName: map['appName'] as String,
          icon: map['icon'] != null ? Uint8List.fromList(List<int>.from(map['icon'])) : null,
        );
      }).toList();

      appList.sort((a, b) => a.appName.compareTo(b.appName));

      appList.insert(0, AppInfo(
        packageName: 'uninstall_protection_dummy',
        appName: 'Uninstall Protection',
        icon: null,
      ));

      for (final app in appList) {
        if (app.icon != null) {
          _iconCache[app.packageName] = MemoryImage(app.icon!);
        }
      }

      final locked = await AppLockService.getLockedApps();

      if (mounted) {
        setState(() {
          _allApps = appList;
          _filteredApps = appList;
          _lockedApps = locked;
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _loading = false);
    }
  }

  // Lightweight refresh used after returning from Settings.
  Future<void> _refreshLockedApps() async {
    if (!mounted) return;
    final locked = await AppLockService.getLockedApps();
    if (mounted) {
      setState(() {
        _lockedApps = locked;
      });
    }
  }

  void _onSearch() {
    final q = _searchController.text.toLowerCase();
    setState(() {
      _searchText = _searchController.text; 
      _filteredApps = q.isEmpty
          ? _allApps
          : _allApps.where((a) => a.appName.toLowerCase().contains(q)).toList();
    });
  }

  void _clearSearch() {
    setState(() {
      _searchController.clear();
      _searchText = '';
    });
    _onSearch();
  }

  Future<void> _toggleLock(AppInfo app) async {
    bool isCurrentlyLocked;
    if (app.packageName == 'uninstall_protection_dummy') {
      isCurrentlyLocked = _lockedApps.contains('com.samsung.android.packageinstaller') ||
                          _lockedApps.contains('com.android.packageinstaller') ||
                          _lockedApps.contains('com.google.android.packageinstaller');
    } else {
      isCurrentlyLocked = _lockedApps.contains(app.packageName);
    }

    setState(() {
      if (app.packageName == 'uninstall_protection_dummy') {
        if (isCurrentlyLocked) {
          _lockedApps.remove('com.android.packageinstaller');
          _lockedApps.remove('com.samsung.android.packageinstaller');
          _lockedApps.remove('com.google.android.packageinstaller');
        } else {
          _lockedApps.add('com.android.packageinstaller');
          _lockedApps.add('com.samsung.android.packageinstaller');
          _lockedApps.add('com.google.android.packageinstaller');
        }
      } else {
        if (isCurrentlyLocked) {
          _lockedApps.remove(app.packageName);
        } else {
          _lockedApps.add(app.packageName);
        }
      }
    });

    await AppLockService.setAppLocked(app.packageName, !isCurrentlyLocked);
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    
    // One UI background colors
    final Color scaffoldBg = isDark ? const Color(0xFF000000) : const Color(0xFFF2F2F7);
    final Color vignetteColor = scaffoldBg;
    
    final Color titleColor = isDark ? Colors.white : const Color(0xFF1C1C1E);
    final Color subtitleColor = isDark ? Colors.grey[400]! : const Color(0xFF8E8E93);
    
    // Gradient opacities matching your reference file
    final double gradientCoreOpacity = isDark ? 0.28 : 0.30;
    final double gradientEdgeOpacity = isDark ? 0.08 : 0.10;

    // Solid One UI styled card containers (no border, no shadow)
    final Color panelColor = isDark ? const Color(0xFF171719) : Colors.white;
    final Color sectionTitleColor = isDark ? Colors.white : const Color(0xFF1C1C1E);
    
    // Subtle locked count
    final Color lockedCountColor = isDark ? Colors.white.withOpacity(0.25) : Colors.black.withOpacity(0.25);
    
    // One UI row divider
    final Color rowDividerColor = isDark ? const Color(0xFF28282B) : const Color(0xFFE5E5EA);
    
    final Color fallbackIconBg = isDark ? const Color(0xFF262629) : const Color(0xFFE5E5EA);
    // Syntax error fixed here
    final Color fallbackIconColor = isDark ? Colors.grey[400]! : Colors.grey[600]!;
    final Color appNameColor = isDark ? Colors.white : const Color(0xFF1C1C1E);
    final Color inactiveTrackColor = isDark ? const Color(0xFF38383A) : const Color(0xFFE5E5EA);
    
    // Search bar surface
    final Color searchBarColor = isDark 
        ? const Color(0xFF232326).withOpacity(0.96) 
        : Colors.white.withOpacity(0.96);
    final Color searchBarShadowColor = isDark 
        ? Colors.black.withOpacity(0.40) 
        : Colors.black.withOpacity(0.08);
        
    final Color searchTextColor = isDark ? Colors.white : const Color(0xFF1C1C1E);
    final Color searchHintColor = isDark ? Colors.white.withOpacity(0.4) : const Color(0xFF8E8E93);
    final Color searchIconColor = isDark ? Colors.white70 : const Color(0xFF636366);

    final bool isKeyboardOpen = MediaQuery.of(context).viewInsets.bottom > 0;
    final double bottomInset = MediaQuery.of(context).padding.bottom;
    final bool isThreeButtonNav = bottomInset > 35.0; 
    
    final double gradientHeight = isThreeButtonNav 
        ? 280.0 + bottomInset 
        : 220.0 + bottomInset;
        
    final double listPaddingBottom = isThreeButtonNav 
        ? 220.0 + bottomInset 
        : 160.0 + bottomInset;

    if (_wasKeyboardOpen && !isKeyboardOpen) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && _searchFocus.hasFocus) {
          _searchFocus.unfocus();
        }
      });
    }
    _wasKeyboardOpen = isKeyboardOpen;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        systemNavigationBarColor: Colors.transparent,
        systemNavigationBarDividerColor: Colors.transparent,
        systemNavigationBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
        systemNavigationBarContrastEnforced: false, 
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
        statusBarBrightness: isDark ? Brightness.dark : Brightness.light,
        systemStatusBarContrastEnforced: false,
      ),
      child: Scaffold(
        backgroundColor: scaffoldBg,
        body: GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
          },
          behavior: HitTestBehavior.translucent,
          child: Stack(
            children: [
              // ── LAYER 1: RADIAL BLUE GRADIENT ──
              Positioned(
                top: -120,
                left: -50,
                right: -50,
                child: RepaintBoundary(
                  child: TweenAnimationBuilder<double>(
                    tween: Tween<double>(begin: 0.0, end: 1.0),
                    duration: const Duration(milliseconds: 1800),
                    curve: const Cubic(0.7, 0.0, 1.0, 0.5), 
                    builder: (context, value, child) {
                      return Transform.scale(
                        scale: 0.5 + (0.5 * value),
                        child: Opacity(
                          opacity: value.clamp(0.0, 1.0),
                          child: child,
                        ),
                      );
                    },
                    child: Center(
                      child: Container(
                        width: 600,
                        height: 600,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(
                            colors: [
                              const Color(0xFF3D8EFF).withOpacity(gradientCoreOpacity),
                              const Color(0xFF3D8EFF).withOpacity(gradientEdgeOpacity),
                              Colors.transparent,
                            ],
                            stops: const [0.0, 0.50, 1.0],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              // ── LAYER 2: SCROLL VIEW ──
              CustomScrollView(
                controller: _scrollController,
                physics: const BouncingScrollPhysics(),
                slivers: [
                  const SliverToBoxAdapter(
                    child: SafeArea(
                      bottom: false,
                      child: SizedBox(height: 256),
                    ),
                  ),
                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    sliver: DecoratedSliver(
                      decoration: BoxDecoration(
                        color: panelColor,
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(28),
                          topRight: Radius.circular(28),
                        ),
                      ),
                      sliver: SliverMainAxisGroup(
                        slivers: [
                          SliverToBoxAdapter(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(28, 24, 28, 14),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(
                                    'Lock Apps',
                                    style: TextStyle(
                                      fontFamily: 'LemonMilk',
                                      fontSize: 18,
                                      fontWeight: FontWeight.w800, // Bold header
                                      color: sectionTitleColor,
                                    ),
                                  ),
                                  const Spacer(),
                                  if (!_loading)
                                    Text(
                                      '$_lockedCount Locked',
                                      style: TextStyle(
                                        fontFamily: 'LemonMilk',
                                        fontSize: 11,
                                        fontWeight: FontWeight.w400,
                                        color: lockedCountColor,
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ),
                          if (_loading)
                            SliverToBoxAdapter(
                              child: SizedBox(
                                height: 300,
                                child: Center(
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation(
                                        isDark ? Colors.white : Colors.black87),
                                  ),
                                ),
                              ),
                            )
                          else
                            SliverPadding(
                              padding: EdgeInsets.only(bottom: listPaddingBottom),
                              sliver: SliverFixedExtentList(
                                itemExtent: 68.0,
                                delegate: SliverChildBuilderDelegate(
                                  (context, index) {
                                    final app = _filteredApps[index];
                                    final isLocked = app.packageName == 'uninstall_protection_dummy'
                                        ? (_lockedApps.contains('com.samsung.android.packageinstaller') ||
                                           _lockedApps.contains('com.android.packageinstaller') ||
                                           _lockedApps.contains('com.google.android.packageinstaller'))
                                        : _lockedApps.contains(app.packageName);

                                    return Stack(
                                      alignment: Alignment.center,
                                      children: [
                                        ListTile(
                                          contentPadding: const EdgeInsets.symmetric(horizontal: 24),
                                          leading: app.packageName == 'uninstall_protection_dummy'
                                              ? _buildUninstallProtectionIcon(context, isDark)
                                              : _iconCache.containsKey(app.packageName)
                                                  ? ClipOval(
                                                      child: Container(
                                                        width: 40,
                                                        height: 40,
                                                        color: fallbackIconBg,
                                                        child: Image(
                                                          image: _iconCache[app.packageName]!,
                                                          fit: BoxFit.cover,
                                                        ),
                                                      ),
                                                    )
                                                  : ClipOval(
                                                      child: Container(
                                                        width: 40,
                                                        height: 40,
                                                        color: fallbackIconBg,
                                                        child: Icon(Icons.apps,
                                                            color: fallbackIconColor, size: 20),
                                                      ),
                                                    ),
                                          title: Text(
                                            app.appName,
                                            style: TextStyle(
                                              fontFamily: 'LemonMilk',
                                              fontSize: 14,
                                              fontWeight: FontWeight.w400, // Lighter app names
                                              color: appNameColor,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          trailing: Transform.scale(
                                            scale: 0.72,
                                            child: Switch(
                                              value: isLocked,
                                              onChanged: (_) => _toggleLock(app),
                                              activeColor: Colors.white,
                                              activeTrackColor: const Color(0xFF3D8EFF),
                                              inactiveThumbColor: Colors.white,
                                              inactiveTrackColor: inactiveTrackColor,
                                              thumbIcon: WidgetStateProperty.resolveWith<Icon?>((states) => const Icon(null)),
                                              trackOutlineColor:
                                                  WidgetStateProperty.all(Colors.transparent),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          bottom: 0,
                                          left: 24,
                                          right: 24,
                                          child: Container(
                                            height: 1,
                                            color: rowDividerColor,
                                          ),
                                        ),
                                      ],
                                    );
                                  },
                                  childCount: _filteredApps.length,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),

              // ── LAYER 3: FIXED HEADER (Fading based on scroll only) ──
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                height: 256,
                child: SafeArea(
                  bottom: false,
                  child: ValueListenableBuilder<double>(
                    valueListenable: _scrollOffsetNotifier,
                    builder: (context, offset, child) {
                      double headerOpacity = 1.0 - (offset / 80.0);
                      headerOpacity = headerOpacity.clamp(0.0, 1.0);

                      return IgnorePointer(
                        ignoring: headerOpacity < 0.1 || _isSearchFocused,
                        child: Opacity(
                          opacity: headerOpacity,
                          child: Stack(
                            clipBehavior: Clip.none,
                            children: [
                              Padding(
                                padding: const EdgeInsets.fromLTRB(24, 110, 24, 80),
                                child: Align(
                                  alignment: Alignment.center,
                                  child: Column(
                                    children: [
                                      Text(
                                        'One Lock',
                                        style: TextStyle(
                                          fontFamily: 'LemonMilk',
                                          fontSize: 44,
                                          fontWeight: FontWeight.w800,
                                          color: titleColor,
                                          letterSpacing: -1.2,
                                          height: 1.1,
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        'Protect Your Privacy',
                                        style: TextStyle(
                                          fontFamily: 'LemonMilk',
                                          fontSize: 14,
                                          fontWeight: FontWeight.w500,
                                          color: subtitleColor,
                                          letterSpacing: 0.2,
                                          height: 1.0,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              // ── 3 DOTS MENU ──
                              Positioned(
                                right: 4, 
                                bottom: 24, 
                                child: PopupMenuButton<String>(
                                  elevation: 8,
                                  shadowColor: searchBarShadowColor, // Matching shadow from search bar
                                  color: isDark 
                                      ? const Color(0xFF232326) // Solid One UI popup
                                      : Colors.white,
                                  surfaceTintColor: Colors.transparent,
                                  offset: const Offset(0, 48), 
                                  icon: Icon(
                                    Icons.more_vert,
                                    color: isDark ? Colors.white : const Color(0xFF1C1C1E),
                                    size: 28,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16),
                                    // Removed border/side completely to match One UI popups
                                  ),
                                  onSelected: (value) {
                                    FocusScope.of(context).unfocus();
                                    _searchFocus.unfocus();
                                    if (mounted && _isSearchFocused) {
                                      setState(() {
                                        _isSearchFocused = false;
                                      });
                                    }
                                    if (value == 'settings') {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(builder: (context) => const SettingsScreen()),
                                      ).then((_) {
                                        _refreshLockedApps();
                                      });
                                    } else if (value == 'about') {
                                      Navigator.pushNamed(context, '/about');
                                    }
                                  },
                                  itemBuilder: (BuildContext context) => [
                                    PopupMenuItem<String>(
                                      value: 'settings',
                                      child: Text(
                                        'Settings',
                                        style: TextStyle(
                                          fontFamily: 'LemonMilk',
                                          fontSize: 14,
                                          color: appNameColor,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ),
                                    PopupMenuItem<String>(
                                      value: 'about',
                                      child: Text(
                                        'About',
                                        style: TextStyle(
                                          fontFamily: 'LemonMilk',
                                          fontSize: 14,
                                          color: appNameColor,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),

              // ── LAYER 4: ENHANCED TOP VIGNETTE GRADIENT ──
              Positioned(
                left: 0,
                right: 0,
                top: 0,
                height: 70,
                child: RepaintBoundary(
                  child: IgnorePointer(
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            vignetteColor.withOpacity(1.0),
                            vignetteColor.withOpacity(0.6),
                            vignetteColor.withOpacity(0.0),
                          ],
                          stops: const [0.0, 0.45, 1.0],
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              // ── LAYER 5: BOTTOM VIGNETTE GRADIENT ──
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                height: gradientHeight,
                child: RepaintBoundary(
                  child: IgnorePointer(
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            vignetteColor.withOpacity(0.0),
                            vignetteColor.withOpacity(1.0),
                          ],
                          stops: const [0.0, 1.0],
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              // ── LAYER 6: SCROLL TO TOP ARROW ──
              Positioned(
                bottom: bottomInset + 92, // Just above search bar with a gap
                left: 0,
                right: 0,
                child: ValueListenableBuilder<double>(
                  valueListenable: _scrollOffsetNotifier,
                  builder: (context, offset, child) {
                    final bool showArrow = offset > 20.0;
                    return AnimatedOpacity(
                      opacity: showArrow && !_isSearchFocused ? 1.0 : 0.0,
                      duration: const Duration(milliseconds: 200),
                      child: IgnorePointer(
                        ignoring: !showArrow || _isSearchFocused,
                        child: Center(
                          child: GestureDetector(
                            onTap: () {
                              _scrollController.animateTo(
                                0.0,
                                duration: const Duration(milliseconds: 350),
                                curve: Curves.easeOutCubic,
                              );
                            },
                            child: Container(
                              width: 44,
                              height: 44,
                              decoration: BoxDecoration(
                                color: searchBarColor,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: searchBarShadowColor,
                                    blurRadius: 12,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Stack(
                                alignment: Alignment.center,
                                children: [
                                  Icon(
                                    Icons.keyboard_arrow_up_rounded,
                                    color: searchIconColor,
                                    size: 26,
                                  ),
                                  Positioned(
                                    top: 13,
                                    child: Container(
                                      width: 10,
                                      height: 2,
                                      decoration: BoxDecoration(
                                        color: searchIconColor,
                                        borderRadius: BorderRadius.circular(1),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),

              // ── LAYER 7: FLOATING SEARCH BAR ──
              Positioned(
                left: 0,
                right: 0,
                bottom: bottomInset + 20, 
                child: AnimatedPadding(
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeOutCubic,
                  padding: EdgeInsets.symmetric(horizontal: _isSearchFocused ? 16 : 70),
                  child: RepaintBoundary(
                    child: Container(
                      height: 56, 
                      decoration: BoxDecoration(
                        color: searchBarColor,
                        borderRadius: BorderRadius.circular(28),
                        boxShadow: [
                          BoxShadow(
                            color: searchBarShadowColor,
                            blurRadius: 18,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 18),
                            child: Image.asset(
                              'assets/mag.png',
                              color: searchIconColor,
                              width: 20,
                              height: 20,
                            ),
                          ),
                          
                          Expanded(
                            child: TextField(
                              controller: _searchController,
                              focusNode: _searchFocus,
                              style: TextStyle(
                                fontFamily: 'LemonMilk',
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: searchTextColor,
                              ),
                              decoration: InputDecoration(
                                hintText: 'Search',
                                hintStyle: TextStyle(
                                  fontFamily: 'LemonMilk',
                                  color: searchHintColor,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                ),
                                border: InputBorder.none,
                                contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 8),
                              ),
                              onChanged: (value) {
                                setState(() {
                                  _searchText = value;
                                });
                                _onSearch();
                              },
                            ),
                          ),
                          
                          Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: _searchText.isNotEmpty
                                ? IconButton(
                                    icon: Icon(Icons.close, color: searchIconColor, size: 22),
                                    onPressed: _clearSearch,
                                    splashRadius: 20,
                                    tooltip: 'Clear search',
                                  )
                                : const SizedBox(width: 44),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildUninstallProtectionIcon(BuildContext context, bool isDark) {
    return ClipOval(
      child: SizedBox(
        width: 40,
        height: 40,
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Always-visible gradient (same colours as icon_bg.png) so the icon
            // never falls back to the panel colour (black/white) if the asset fails.
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFFFFFFFF), Color(0xFF5BBFD7), Color(0xFF2F06A0)],
                  stops: [0.0, 0.4, 1.0],
                ),
              ),
            ),
            // The real icon_bg.png drawn on top when it loads.
            Image.asset(
              'assets/icon_bg.png',
              fit: BoxFit.cover,
              gaplessPlayback: true,
              errorBuilder: (context, error, stackTrace) {
                debugPrint('icon_bg.png failed to load: $error');
                return const SizedBox.shrink();
              },
            ),
            Center(
              child: Image.asset(
                'assets/shield.png',
                width: 32,
                height: 32,
                fit: BoxFit.contain,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}