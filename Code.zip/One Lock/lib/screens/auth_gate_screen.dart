import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/auth_service.dart';

class AuthGateScreen extends StatefulWidget {
  const AuthGateScreen({super.key});

  @override
  State<AuthGateScreen> createState() => _AuthGateScreenState();
}

class _AuthGateScreenState extends State<AuthGateScreen> {
  static const platform = MethodChannel('com.onelock.applock/apps');

  bool _isAuthenticating = false;
  bool _isPressed = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _tryBiometric());
  }

  Future<void> _tryBiometric() async {
    if (_isAuthenticating) return;
    setState(() {
      _isAuthenticating = true;
    });

    try {
      final ok = await AuthService.authenticateWithBiometric(reason: '');

      if (ok && mounted) {
        final bool hasUsage = await platform.invokeMethod('hasUsageStats') ?? false;
        final bool hasOverlay = await platform.invokeMethod('hasOverlayPermission') ?? false;

        if (!mounted) return;

        if (hasUsage && hasOverlay) {
          Navigator.of(context).pushReplacementNamed('/home');
        } else {
          Navigator.of(context).pushReplacementNamed('/instruction');
        }
      } else if (mounted) {
        setState(() {
          _isAuthenticating = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isAuthenticating = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final Color textColor = isDark ? Colors.white : Colors.black87;
    final Color subTextColor = isDark ? Colors.white70 : Colors.black54;

    // Calculate safe dynamic bottom inset
    final double bottomInset = MediaQuery.of(context).padding.bottom;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        systemNavigationBarColor: Colors.transparent,
        systemNavigationBarDividerColor: Colors.transparent,
        systemNavigationBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
        systemNavigationBarContrastEnforced: false,
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
        systemStatusBarContrastEnforced: false,
      ),
      child: Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: SizedBox(
          width: double.infinity,
          child: Column(
            children: [
              // --- TOP HEADER ---
              SafeArea(
                bottom: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(24, 110, 24, 20),
                  child: Column(
                    children: [
                      Text(
                        'One Lock',
                        style: TextStyle(
                          fontFamily: 'LemonMilk',
                          fontSize: 44,
                          fontWeight: FontWeight.w800,
                          color: textColor,
                          letterSpacing: -1.2,
                          height: 1.1,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Verify to continue',
                        style: TextStyle(
                          fontFamily: 'LemonMilk',
                          fontSize: 14,
                          color: subTextColor,
                          fontWeight: FontWeight.w500,
                          letterSpacing: 0.2,
                          height: 1.0,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // --- NO INDICATOR ---
              const SizedBox(height: 36),

              // --- SPACER ---
              const Spacer(flex: 3),

              // --- TEXT ABOVE THE ICON (Smaller) ---
              Padding(
                padding: const EdgeInsets.only(bottom: 16.0),
                child: Text(
                  'Tap fingerprint to unlock',
                  style: TextStyle(
                    fontFamily: 'LemonMilk',
                    fontSize: 10,
                    color: textColor,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 0.2,
                  ),
                ),
              ),

              // --- FINGERPRINT ICON BELOW THE TEXT ---
              GestureDetector(
                onTap: _tryBiometric,
                onTapDown: (_) => setState(() => _isPressed = true),
                onTapUp: (_) => setState(() => _isPressed = false),
                onTapCancel: () => setState(() => _isPressed = false),
                behavior: HitTestBehavior.opaque,
                child: AnimatedScale(
                  scale: _isPressed ? 0.85 : 1.0,
                  duration: const Duration(milliseconds: 120),
                  curve: Curves.easeOut,
                  child: Image.asset(
                    'assets/fingerprint_icon.png',
                    width: 43,
                    height: 43,
                    color: textColor,
                  ),
                ),
              ),

              const Spacer(flex: 2),

              // --- BOTTOM EXIT CONTROL (SMALLER & GREY) ---
              TextButton(
                onPressed: () => SystemNavigator.pop(),
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                  minimumSize: Size.zero,
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
                child: Text(
                  'EXIT',
                  style: TextStyle(
                    fontFamily: 'LemonMilk',
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: textColor.withOpacity(0.4),
                    letterSpacing: 1.0,
                  ),
                ),
              ),
              
              SizedBox(height: 16 + bottomInset),
            ],
          ),
        ),
      ),
    );
  }
}