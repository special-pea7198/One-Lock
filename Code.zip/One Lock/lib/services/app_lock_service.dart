import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class AppLockService {
  // ── FIX: Changed key to start fresh with pure, uncorrupted JSON data ──
  static const String _lockedAppsKey = 'one_lock_locked_apps_json';
  
  static const List<String> _installerPackages = [
    'com.android.packageinstaller',
    'com.google.android.packageinstaller',
    'com.samsung.android.packageinstaller',
  ];

  static Future<Set<String>> getLockedApps() async {
    final prefs = await SharedPreferences.getInstance();
    final String? stored = prefs.getString(_lockedAppsKey);
    if (stored == null) return {};
    try {
      final List<dynamic> decoded = jsonDecode(stored);
      return decoded.map((e) => e.toString()).toSet();
    } catch (e) {
      return {};
    }
  }

  static Future<void> setAppLocked(String packageName, bool locked) async {
    final prefs = await SharedPreferences.getInstance();
    final Set<String> current = await getLockedApps();
    
    if (packageName == 'uninstall_protection_dummy') {
      if (locked) {
        current.addAll(_installerPackages);
      } else {
        current.removeAll(_installerPackages);
      }
    } else {
      if (locked) {
        current.add(packageName);
      } else {
        current.remove(packageName);
      }
    }
    // ── FIX: Save as pure JSON string instead of stringList ──
    await prefs.setString(_lockedAppsKey, jsonEncode(current.toList()));
  }

  static Future<bool> isAppLocked(String packageName) async {
    final locked = await getLockedApps();
    if (packageName == 'uninstall_protection_dummy') {
      return locked.contains('com.samsung.android.packageinstaller') || 
             locked.contains('com.google.android.packageinstaller') || 
             locked.contains('com.android.packageinstaller');
    }
    return locked.contains(packageName);
  }
}