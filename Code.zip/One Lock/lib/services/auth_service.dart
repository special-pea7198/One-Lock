import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
// ── NEW: Required for Android-specific prompt customization ──
import 'package:local_auth_android/local_auth_android.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class AuthService {
  static final LocalAuthentication _localAuth = LocalAuthentication();
  static const FlutterSecureStorage _storage = FlutterSecureStorage();
  static const String _mpinKey = 'one_lock_mpin';

  // ── MPIN ──────────────────────────────────────────────────────────────────

  static String _hashPin(String pin) {
    final bytes = utf8.encode(pin);
    return sha256.convert(bytes).toString();
  }

  static Future<void> saveMpin(String pin) async {
    await _storage.write(key: _mpinKey, value: _hashPin(pin));
  }

  static Future<bool> verifyMpin(String pin) async {
    final stored = await _storage.read(key: _mpinKey);
    if (stored == null) return false;
    return stored == _hashPin(pin);
  }

  static Future<bool> hasMpin() async {
    final val = await _storage.read(key: _mpinKey);
    return val != null;
  }

  // ── BIOMETRIC ─────────────────────────────────────────────────────────────

  static Future<bool> isBiometricAvailable() async {
    try {
      final bool canAuth = await _localAuth.canCheckBiometrics;
      final bool isDeviceSupported = await _localAuth.isDeviceSupported();
      return canAuth && isDeviceSupported;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> authenticateWithBiometric({
    required String reason,
  }) async {
    try {
      return await _localAuth.authenticate(
        localizedReason: reason,
        // ── NEW: Overrides the OS default texts ──
        authMessages: const <AuthMessages>[
          AndroidAuthMessages(
            signInTitle: 'Authentication Required', // Replaces "Authentication required"
            biometricHint: null,       // Removes "Verify identity"
          ),
        ],
        options: const AuthenticationOptions(
          biometricOnly: false, // allows face + fingerprint
          stickyAuth: true,
          useErrorDialogs: true,
        ),
      );
    } catch (_) {
      return false;
    }
  }

  // ── COMBINED (biometric OR mpin via dialog) ────────────────────────────────

  static Future<bool> authenticateWithBiometricOrMpin({
    required BuildContext context,
    required String reason,
  }) async {
    // Try biometric first
    final bioAvailable = await isBiometricAvailable();
    if (bioAvailable) {
      final bioResult = await authenticateWithBiometric(reason: reason);
      if (bioResult) return true;
    }

    // Fallback to MPIN dialog
    if (context.mounted) {
      return await showMpinDialog(context: context);
    }
    return false;
  }

  // ── MPIN DIALOG ───────────────────────────────────────────────────────────

  static Future<bool> showMpinDialog({required BuildContext context}) async {
    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => const _MpinDialog(),
    );
    return result ?? false;
  }
}

// ── MPIN DIALOG WIDGET ────────────────────────────────────────────────────────

class _MpinDialog extends StatefulWidget {
  const _MpinDialog();

  @override
  State<_MpinDialog> createState() => _MpinDialogState();
}

class _MpinDialogState extends State<_MpinDialog> {
  final List<String> _entered = [];
  bool _error = false;
  static const int _pinLength = 6;

  void _onKey(String digit) {
    if (_entered.length >= _pinLength) return;
    setState(() {
      _entered.add(digit);
      _error = false;
    });
    if (_entered.length == _pinLength) _verify();
  }

  void _onDelete() {
    if (_entered.isEmpty) return;
    setState(() => _entered.removeLast());
  }

  Future<void> _verify() async {
    final pin = _entered.join();
    final ok = await AuthService.verifyMpin(pin);
    if (ok) {
      if (mounted) Navigator.of(context).pop(true);
    } else {
      setState(() {
        _entered.clear();
        _error = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 32, 24, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Lock icon
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF5BC8F5), Color(0xFF6C63FF)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Icon(Icons.lock_rounded, color: Colors.white, size: 28),
            ),
            const SizedBox(height: 16),
            const Text(
              'Enter MPIN',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            Text(
              _error ? 'Incorrect PIN. Try again.' : 'Enter your 6-digit PIN',
              style: TextStyle(
                fontSize: 13,
                color: _error ? Colors.red : Colors.grey[600],
              ),
            ),
            const SizedBox(height: 24),
            // PIN dots
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(_pinLength, (i) {
                final filled = i < _entered.length;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  margin: const EdgeInsets.symmetric(horizontal: 6),
                  width: 14,
                  height: 14,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: filled
                        ? (_error ? Colors.red : const Color(0xFF6C63FF))
                        : Colors.grey[300],
                  ),
                );
              }),
            ),
            const SizedBox(height: 28),
            // Numpad
            _buildNumpad(),
            const SizedBox(height: 8),
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Cancel'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNumpad() {
    final keys = [
      ['1','2','3'],
      ['4','5','6'],
      ['7','8','9'],
      ['','0','⌫'],
    ];
    return Column(
      children: keys.map((row) {
        return Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: row.map((k) {
            if (k.isEmpty) return const SizedBox(width: 72, height: 56);
            return GestureDetector(
              onTap: () => k == '⌫' ? _onDelete() : _onKey(k),
              child: Container(
                width: 72,
                height: 56,
                alignment: Alignment.center,
                child: Text(
                  k,
                  style: TextStyle(
                    fontSize: k == '⌫' ? 20 : 24,
                    fontWeight: FontWeight.w500,
                    color: Colors.black87,
                  ),
                ),
              ),
            );
          }).toList(),
        );
      }).toList(),
    );
  }
}