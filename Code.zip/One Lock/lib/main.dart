import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/auth_gate_screen.dart';
import 'screens/home_screen.dart';
import 'screens/about_screen.dart';
import 'screens/instruction_screen.dart';
// Make sure this path matches where you saved your settings.dart file
import 'screens/settings.dart'; 

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Enable edge-to-edge mode so full screen immersion works properly
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

  // Set initial system bar styles (dynamic icon brightness is handled in screens via AnnotatedRegion)
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      systemNavigationBarColor: Colors.transparent,
      systemNavigationBarDividerColor: Colors.transparent,
    ),
  );

  runApp(const OneLockApp());
}

class OneLockApp extends StatefulWidget {
  const OneLockApp({super.key});
  @override
  State<OneLockApp> createState() => _OneLockAppState();
}

class _OneLockAppState extends State<OneLockApp> with WidgetsBindingObserver {
  final GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();
  bool _wasInBackground = false;
  
  // Platform channel to check if setup is fully completed
  static const platform = MethodChannel('com.onelock.applock/apps');

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _wasInBackground = true;
    } else if (state == AppLifecycleState.resumed) {
      if (_wasInBackground) {
        _wasInBackground = false;
        _checkPermissionsAndLock(); 
      }
    }
  }

  Future<void> _checkPermissionsAndLock() async {
    try {
      final bool hasUsage = await platform.invokeMethod('hasUsageStats') ?? false;
      final bool hasOverlay = await platform.invokeMethod('hasOverlayPermission') ?? false;

      // Only force lock on resume if the user has completed BOTH mandatory setup steps
      if (hasUsage && hasOverlay) {
        _forceLock();
      }
    } catch (e) {
      _forceLock(); // Failsafe
    }
  }

  void _forceLock() {
    bool isAlreadyAtAuth = false;
    _navigatorKey.currentState?.popUntil((route) {
      if (route.settings.name == '/auth') {
        isAlreadyAtAuth = true;
      }
      return true;
    });
    if (!isAlreadyAtAuth) {
      _navigatorKey.currentState?.pushNamedAndRemoveUntil(
          '/auth', (route) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    // ── FIX: Listens to the global theme notifier to dynamically switch themes ──
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: appThemeNotifier,
      builder: (context, currentThemeMode, child) {
        return MaterialApp(
          navigatorKey: _navigatorKey,
          title: 'One Lock',
          debugShowCheckedModeBanner: false,
          themeMode: currentThemeMode, // Applies the active theme choice instantly
          theme: ThemeData(
            brightness: Brightness.light,
            scaffoldBackgroundColor: Colors.white,
            colorScheme: const ColorScheme.light(
              primary: Color(0xFF3D8EFF),
              surface: Colors.white,
            ),
            useMaterial3: true,
          ),
          darkTheme: ThemeData(
            brightness: Brightness.dark,
            scaffoldBackgroundColor: Colors.black,
            colorScheme: const ColorScheme.dark(
              primary: Color(0xFF3D8EFF),
              surface: Colors.black,
            ),
            useMaterial3: true,
          ),
          home: const AuthGateScreen(),
          routes: {
            '/home':        (context) => const HomeScreen(),
            '/auth':        (context) => const AuthGateScreen(),
            '/about':       (context) => const AboutScreen(),
            '/instruction': (context) => const InstructionScreen(),
            '/settings':    (context) => const SettingsScreen(), // ── ADDED SETTINGS ROUTE ──
          },
        );
      },
    );
  }
}